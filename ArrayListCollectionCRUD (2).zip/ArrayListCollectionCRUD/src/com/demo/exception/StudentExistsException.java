package com.demo.exception;

public class StudentExistsException extends Exception{
   public StudentExistsException(String msg) {
	   super(msg);
   }
}
