package com.demo.exception;

public class NoNegativeMarksException extends Exception{
	
	public NoNegativeMarksException(String message) {
		super(message);
	}

}
