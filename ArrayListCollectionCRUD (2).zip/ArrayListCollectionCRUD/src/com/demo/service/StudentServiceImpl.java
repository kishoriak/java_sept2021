package com.demo.service;

import java.util.Collection;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Stream;

import com.demo.beans.Student;
import com.demo.dao.MyDaoFactory;
import com.demo.dao.StudentDao;
import com.demo.dao.StudentDaoImpl;
import com.demo.dao.StudentHashSetDaoImpl;
import com.demo.exception.NoNegativeMarksException;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotCreatedException;
import com.demo.exception.StudentNotFoundException;

public  class StudentServiceImpl implements StudentService{
	private StudentDao studentDao;
	public StudentServiceImpl(int num) {
		
		studentDao=(StudentDao) MyDaoFactory.getStudentDao(num);
	}
	
	//accept data from user and create student object
	@Override
	public void addStudent() throws StudentNotCreatedException,StudentExistsException, StudentNotFoundException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String nm=sc.next();
		//this gives 3 chances to user to accept marks
		for(int i=0;i<3;i++) {
		try {
				System.out.println("enter m1");
				int m1=sc.nextInt();
				if(m1<0) {
					throw new NoNegativeMarksException("marks should be > 0");
				}
				System.out.println("enter m2");
				int m2=sc.nextInt();
				if(m2<0) {
					throw new NoNegativeMarksException("marks should be > 0");
				}
				System.out.println("enter m3");
				int m3=sc.nextInt();
				if(m3<0) {
					throw new NoNegativeMarksException("marks should be > 0");
				}
				studentDao.saveStudent(new Student(id,nm,m1,m2,m3));
				break;
		}catch(NoNegativeMarksException e) {
			System.out.println(e.getMessage());
			if(i==2) {
				throw new StudentNotCreatedException("Student object not created",e);
			}
		}
		}
	}
	@Override
	public void displayAll() {
	 List<Student> slist=studentDao.getAll();
	 slist.stream().forEach(System.out::println);
		
	}
	/*@Override
	public void writedata() {
		studentDao.writeToFile();
		
	}
	@Override
	public void readData() {
		studentDao.readFromFile();
		
	}*/
	@Override
	public Student searchById(int id) throws StudentNotFoundException {
		return studentDao.findById(id);
	}

	@Override
	public List<Student> searchByName(String nm) throws StudentNotFoundException {
		return studentDao.findByName(nm);
	}

	@Override
	public boolean deleteById(int id) throws StudentNotFoundException {
		return studentDao.deleteById(id);
	}

	@Override
	public boolean updateStudent(int id, float m1, float m2, float m3) throws StudentNotFoundException {
		return studentDao.updateById(id,m1,m2,m3);
		
	}

	@Override
	public void sortByName() {
		if(studentDao instanceof StudentDaoImpl) {
			List<Student> slist= ((StudentDaoImpl)studentDao).sortByName();
			slist.stream().forEach(System.out::println);
		}else {
			Set<Student> slist= ((StudentHashSetDaoImpl)studentDao).sortByName();
			slist.stream().forEach(System.out::println);
		}
		
		
		
		
	}

}
