package com.demo.comparators;

import java.util.Comparator;

import com.demo.beans.Student;

public class NameComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		System.out.println("Compare called "+o1.getSname()+"-----"+o2.getSname());
		return o1.getSname().compareTo(o2.getSname());
	}

}
/*
Comparable
Comparator
Predicate
Supplier
Consumer
Function
*/