package com.demo.comparators;

import java.util.Comparator;

import com.demo.beans.Student;

public class IdComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		/*if(o1.getSid()<o2.getSid())
			return -1;
		else if (o1.getSid()==o2.getSid())
			return (o1.getSname().compareTo(o2.getSname());
		else 
			return 1;*/
		return o1.getSid()-o2.getSid();
		
	}

}
