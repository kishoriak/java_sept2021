package com.demo.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.demo.beans.Student;
import com.demo.comparators.NameComparator;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotFoundException;

public class StudentDaoImpl implements StudentDao{
	
	private static List<Student> slist;

	static {
		slist = new ArrayList<>();
		slist.add(new Student(5, "nagesh", 3, 3, 3));
		slist.add(new Student(7, "Ashu", 4, 4, 4));
		slist.add(new Student(10, "sangeeta", 6, 6, 6));
		slist.add(new Student(12, "yogesh", 4, 4, 4));
	}
	

	@Override
	public void saveStudent(Student student) throws StudentExistsException {
		if(slist.contains(student))
			  throw new StudentExistsException(" student already exists");
		slist.add(student);
		
	}


	
	public List<Student> getAll() {
		return slist;
	}


	@Override
	public Student findById(int id) throws StudentNotFoundException {
		/*for(Student s:slist) {
			if(s.getSid()==id) {
				return s;
			}
		}*/
		int pos=slist.indexOf(new Student(id));
		if(pos==-1) {
			throw new StudentNotFoundException("Student not found");
		}
		else {
			return slist.get(pos);
		}
	}


	@Override
	public List<Student> findByName(String nm) throws StudentNotFoundException {
		List<Student> slist1=new ArrayList<>();
		for(Student s:slist) {
			if(s.getSname().equals(nm)) {
				slist1.add(s);
			}
		}
		if(slist1.size()>0)
			  return slist1;
		throw new StudentNotFoundException("Student not found by name");
	}


	@Override
	public boolean deleteById(int id) throws StudentNotFoundException {
		if(slist.remove(new Student(id)))
			return true;
		throw new StudentNotFoundException("Student not found");
	}


	@Override
	public boolean updateById(int id, float m1, float m2, float m3) throws StudentNotFoundException {
		int pos=slist.indexOf(new Student(id));
		if(pos!=-1) {
			Student s=slist.get(pos);
			s.setM1(m1);
			s.setM2(m2);
			s.setM3(m3);
			return true;
			
		}
		throw new StudentNotFoundException("Student not found");
	}


	
	public List<Student> sortByName() {
		List<Student> copySlist=new ArrayList<>(100);
		//Collections.copy(copySlist,slist);
		//Collections.sort(slist);
		Collections.sort(slist, new NameComparator());
		return copySlist;
	}

}
