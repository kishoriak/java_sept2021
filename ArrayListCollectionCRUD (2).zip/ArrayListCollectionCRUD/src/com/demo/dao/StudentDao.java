package com.demo.dao;

import java.util.List;

import com.demo.beans.Student;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotFoundException;

public interface StudentDao {

	void saveStudent(Student student) throws StudentExistsException;

	//List<Student> getAll();

	Student findById(int id) throws StudentNotFoundException;

	List<Student> findByName(String nm) throws StudentNotFoundException;

	boolean deleteById(int id) throws StudentNotFoundException;

	boolean updateById(int id, float m1, float m2, float m3) throws StudentNotFoundException;

	//List<Student> sortByName();

}
