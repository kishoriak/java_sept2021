package com.demo.dao;

public class MyDaoFactory {

	public static StudentDao getStudentDao(int num) {
		if (num==1)
			return new StudentDaoImpl();
		else
			return new StudentHashSetDaoImpl();
	}

}
