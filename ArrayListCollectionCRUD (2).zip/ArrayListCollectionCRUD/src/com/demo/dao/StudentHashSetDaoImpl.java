package com.demo.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Student;
import com.demo.comparators.NameComparator;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotFoundException;

public class StudentHashSetDaoImpl implements StudentDao{
    private static Set<Student> sset;
    static {
    	sset=new HashSet<>();
    }
	  
	@Override
	public void saveStudent(Student student) throws StudentExistsException {
		sset.add(student);
		
	}

	
	public Set<Student> getAll() {
		// TODO Auto-generated method stub
		return sset;
	}

	@Override
	public Student findById(int id) throws StudentNotFoundException {
		for(Student s:sset) {
			if(s.getSid()==id) {
				return s;
			}
		}
		throw new StudentNotFoundException("Student not found");
	}

	@Override
	public List<Student> findByName(String nm) throws StudentNotFoundException {
		List<Student> slist=new ArrayList<>();
		for(Student s:sset) {
			if(s.getSname().equals(nm)) {
				slist.add(s);
			}
		}
		return slist;
	}

	@Override
	public boolean deleteById(int id) throws StudentNotFoundException {
		if(sset.remove(new Student(id))) {
			return true;
		}
		throw new StudentNotFoundException("student not found");
	}

	@Override
	public boolean updateById(int id, float m1, float m2, float m3) throws StudentNotFoundException {
	
			Student s=findById(id);
			s.setM1(m1);
			s.setM2(m2);
			s.setM3(m3);
		    return true;
		
	}


	public Set<Student> sortByName() {
		//TreeSet<Student> ts=new TreeSet<>(new NameComparator());
		TreeSet<Student> ts=new TreeSet<>();
		Iterator<Student> it=sset.iterator();
		while(it.hasNext()) {
			Student s=it.next();
			ts.add(s);
		}
		return ts;
	}

}
