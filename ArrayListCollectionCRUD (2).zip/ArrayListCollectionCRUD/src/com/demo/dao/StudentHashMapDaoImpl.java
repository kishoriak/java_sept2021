package com.demo.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.demo.beans.Student;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotFoundException;

public class StudentHashMapDaoImpl implements StudentDao{
	private static Map<Integer,Student> hm;
	static {
		hm=new HashMap<>();
	}

	@Override
	public void saveStudent(Student student) throws StudentExistsException {
		if(hm.containsKey(student.getSid())) {
			throw new StudentExistsException("Student exists");
		}
		hm.put(student.getSid(), student);
		
	}

	@Override
	public Student findById(int id) throws StudentNotFoundException {
		Student s=hm.get(id);
		if(s!=null) {
			return s;
		}
		throw new StudentNotFoundException("Not found");
	}

	@Override
	public List<Student> findByName(String nm) throws StudentNotFoundException {
		Set<Integer> keys=hm.keySet();
		List<Student> slist=new ArrayList<>();
		for(Integer id:keys) {
			Student s=hm.get(id);
			if(s.getSname().equals(nm)) {
				slist.add(s);
			}
			
		}
		if(slist.size()>0) {
			return slist;
		}
		throw new StudentNotFoundException("not found");
	}

	@Override
	public boolean deleteById(int id) throws StudentNotFoundException {
		if(hm.remove(id)!=null) {
			return true;
		}
		throw new StudentNotFoundException("not found")
	}

	@Override
	public boolean updateById(int id, float m1, float m2, float m3) throws StudentNotFoundException {
		Student s=hm.get(id);
		if(s!=null) {
		s.setM1(m1);
		s.setM2(m2);
		s.setM3(m3);
		return true;
		}
		throw new StudentNotFoundException("not found");
		
	}
	
	public Map<String,Student> sortByName(){
		Map<String,Student> tm=new TreeMap<>();
		Set<Map.Entry<Integer,Student>> keys=hm.entrySet();
		for(Map.Entry<Integer,Student> entry:keys) {
			Student s=entry.getValue();
			tm.put(s.getSname(),s);
		}
		return tm;
		
	}

}
