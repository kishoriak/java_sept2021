
public class TestString {

	public static void main(String[] args) {
		String s1="Hello";
		String s2="welcome";
		String s3=new String("Hello");
		String s4=new String("Welcome");
		if(s1.equals(s3)) {
			System.out.println("equals");
		}
		else {
			System.out.println("not equal");
		}
		
		String s6="MyString";
		s6.replace("String", "data");
		System.out.println(s6);
		
		
		

	}

}
