package com.demo.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.demo.beans.Product;
import com.demo.service.ProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController 
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productService;
	
	@GetMapping("/products")
	public List<Product> displayProducts() {
		List<Product> plist=productService.getAllProduct();
		return plist;
		
	}
	
	@GetMapping("/products/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable int id) {
		Product p1=productService.getById(id);
		if(p1!=null) {
			return ResponseEntity.ok(p1);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		
	}
	
	
	@PostMapping("/products/{id}")
	public ResponseEntity<Product> addProductDetails(@RequestBody Product p) {
		productService.addProduct(p);
		Product p1=productService.getById(p.getPid());
		if(p1!=null) {
			return ResponseEntity.ok(p1);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
	
	
	
	@PutMapping("/products/{pid}")
	public ResponseEntity<Product> editProductDetails(@RequestBody Product p) {
		productService.updateProduct(p);
		Product p1=productService.getById(p.getPid());
		if(p1!=null) {
			return ResponseEntity.ok(p1);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
	
	@DeleteMapping("/products/{pid}")
	public ResponseEntity<String> deleteProduct(@PathVariable int pid) {
		boolean status=productService.deleteById(pid);
		if(status) {
			return new ResponseEntity("Deleted successfully"+pid,HttpStatus.OK);
		}
		return new ResponseEntity("Product not found"+pid,HttpStatus.NOT_FOUND);
	}
	
	
	
	

}
