package com.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.demo.beans.Product;

@Repository
public class ProductDaoImpl implements ProductDao{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public void save(Product p) {
		String query="insert into producthsbc values(?,?,?,?,?)";
		int n=jdbcTemplate.update(query,new Object[] {p.getPid(),p.getPname(),p.getQty(),p.getPrice(),p.getMfgdate()});
		
	}

	
	public List<Product> findAll() {
		String sql="select * from producthsbc";
		/*RowMapper<Product> rm=(rs,num)->{
			Product p=new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setQty(rs.getInt(3));
			p.setPrice(rs.getDouble(4));
			p.setMfgdate(rs.getDate(5).toLocalDate());
			return p;
		};
		List<Product> plist=jdbcTemplate.query(sql,rm);
		*/
		return jdbcTemplate.query(sql,(rs,num)->{
			Product p=new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setQty(rs.getInt(3));
			p.setPrice(rs.getDouble(4));
			p.setMfgdate(rs.getDate(5).toLocalDate());
			return p;
		});
		
	}

	
	public Product findById(int id) {
		String sql="select * from producthsbc where pid=?";
		//return jdbcTemplate.queryForObject(sql,new Object[] {id}, new BeanPropertyRowMapper<Product>());
		try {
		return  jdbcTemplate.queryForObject(sql,new Object[] {id},(rs,num)->{
			Product p=new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setQty(rs.getInt(3));
			p.setPrice(rs.getDouble(4));
			p.setMfgdate(LocalDate.now());
			return p;
		});
		}catch(EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public int updateById(Product p) {
		String query="update producthsbc set pname=?,qty=?,price=? where pid=?";
		return jdbcTemplate.update(query,new Object[] {p.getPname(),p.getQty(),p.getPrice(),p.getPid()});
	}

	@Override
	public boolean deleteById(int pid) {
		String query="delete from producthsbc where pid=?";
		int n=jdbcTemplate.update(query,new Object[] {pid});
		if(n>0) {
			return true;
		}
		else {
			return false;
		}
		
	}

}
