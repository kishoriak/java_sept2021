export class Product{
        pid:number;
		pname:string ;
		qty:number ;
		price:number;
		mfgdate:Date;
        constructor(id:number,nm:string,qty:number,price:number,mfgdate:Date){
            this.pid=id;
            this.pname=nm;
            this.qty=qty;
            this.price=price;
            this.mfgdate=mfgdate;
        }
}