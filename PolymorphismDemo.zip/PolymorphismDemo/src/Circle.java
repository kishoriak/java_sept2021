
public class Circle extends Shape{
	private float radius;
	private final static float pi=3.142f;
	
	
	public Circle() {
		super();
		
	}

	public Circle(String color,int dim,float radius) {
		super(color,dim);
		this.radius = radius;
	}

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	public float calculateArea() {
		return pi*radius*radius;
	}

	 public float calculatePerimeter() {
		 return 2*pi*radius;
	 }
	 public void showCircle() {
		 System.out.println("in show circle");
	 }
	 
	@Override
	public String toString() {
		return super.toString()+"Circle [radius=" + radius + "]";
	}
	

}
