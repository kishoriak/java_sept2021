import java.util.Scanner;

public class TestShapeDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice;
		do {
		System.out.println("1.Triangle\n2.Circle\n3.Rectangle\n4.Exit\n");
		choice=sc.nextInt();
		Shape s=null;
		switch(choice) {
		//triangle class
		case 1:
			s=new Triangle("red",2,12,2,3,4);
			break;
			//circle class
		case 2:
			s=new Circle("white",2,4);
			
			break;
		case 3:
			break;
		case 4:
			System.exit(0);
			break;
		}
		System.out.println("Area: "+s.calculateArea());
		System.out.println("Perimeter: "+s.calculatePerimeter());
		if(s instanceof Triangle) {
			((Triangle)s).showTriangle();
		}
		else if(s instanceof Circle) {
			((Circle)s).showCircle();
		}
		else {
			System.out.println("rectangle");
		}
		}while(choice!=4);

	}

}
