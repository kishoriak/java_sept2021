
public class ShapeDao {
	private static Shape[] shapearr;
	private static int cnt;
	static {
		shapearr=new Shape[10];
		shapearr[0]=new Triangle("r",2,3,2,4,5);
		shapearr[1]=new Triangle("w",5,3,2,4,5);
		shapearr[2]=new Circle("r",2,10);
		cnt=3;
	}
	public void addData(Shape s) {
		shapearr[cnt]=s;
		cnt++;
	}
	public float getArea(int pos) {
		if (pos<cnt)
		   return shapearr[pos].calculateArea();
		return -1;
	}
	public float getPerimeter(int pos) {
		if (pos<cnt)
			   return shapearr[pos].calculatePerimeter();
			return -1;
	}
	public Shape[] getAllShapes() {
		return shapearr;
	}

}
