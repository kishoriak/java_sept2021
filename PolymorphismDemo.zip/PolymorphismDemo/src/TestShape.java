
public class TestShape {

	public static void main(String[] args) {
		Triangle t=new Triangle("yellow",2,5,6,7,2);
		System.out.println(t);
		System.out.println("Area: "+t.calculateArea());
		System.out.println("Perimeter: "+t.calculatePerimeter());
		Circle c=new Circle("red",2,4);
		System.out.println(c);
		System.out.println("Area: "+c.calculateArea());
		System.out.println("Perimeter: "+c.calculatePerimeter());

	}

}
