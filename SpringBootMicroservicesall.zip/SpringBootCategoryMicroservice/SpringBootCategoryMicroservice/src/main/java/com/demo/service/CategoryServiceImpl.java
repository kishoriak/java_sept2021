package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.beans.Category;
import com.demo.dao.CategoryDao;

@Service
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired
	CategoryDao categoryDao;

	@Override
	public Category getById(int cid) {
		return categoryDao.getCategoryById(cid);
	}

}
