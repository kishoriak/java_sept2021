package com.demo.beans;

public class Category {
      private int catid;
      private String cname;
      private String description;
	public Category() {
		super();
	}
	public Category(int catid, String cname, String description) {
		super();
		this.catid = catid;
		this.cname = cname;
		this.description = description;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Category [catid=" + catid + ", cname=" + cname + ", description=" + description + "]";
	}
      
      
}
