package com.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.demo.beans.Category;

@Repository
public class CategoryDaoImpl implements CategoryDao{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public Category getCategoryById(int cid) {
		String sql="select * from category where catid=?";
		try {
		   return jdbcTemplate.queryForObject(sql,new Object[] {cid},BeanPropertyRowMapper.newInstance(Category.class));
		}catch(EmptyResultDataAccessException e) {
			return null;
		}
		
	}

}
