package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.demo.beans.Category;
import com.demo.service.CategoryService;

@RestController
public class CategoryController {
	
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/category/{cid}")
	public String getAllProductsByCategory(@PathVariable int cid) {
		Category c=categoryService.getById(cid);
		System.out.println(c);
		/*String response= restTemplate.exchange("http://localhost:8282/product/{cid}",HttpMethod.GET,null,
				new ParameterizedTypeReference<String>() {},cid).getBody();*/
		String response= restTemplate.exchange("http://productservice/product/{cid}",HttpMethod.GET,null,
				new ParameterizedTypeReference<String>() {},cid).getBody();
		System.out.println("Response received"+response);
		return "Category name :"+c.getCname()+"category description  : "+c.getDescription() + "\nProduct details"+response;
		
		/*if(c!=null) {
			return ResponseEntity.ok(c);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();*/
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
