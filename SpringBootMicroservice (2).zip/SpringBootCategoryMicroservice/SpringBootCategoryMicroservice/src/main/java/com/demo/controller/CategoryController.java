package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.beans.Category;
import com.demo.service.CategoryService;

@RestController
public class CategoryController {
	
	@Autowired
	CategoryService categoryService;
	
	@GetMapping("/category/{cid}")
	public ResponseEntity<Category> getAllProductsByCategory(@PathVariable int cid) {
		Category c=categoryService.getById(cid);
		if(c!=null) {
			return ResponseEntity.ok(c);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}

}
