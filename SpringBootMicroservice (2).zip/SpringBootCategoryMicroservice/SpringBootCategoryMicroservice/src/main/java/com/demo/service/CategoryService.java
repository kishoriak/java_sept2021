package com.demo.service;

import com.demo.beans.Category;

public interface CategoryService {

	Category getById(int cid);

}
