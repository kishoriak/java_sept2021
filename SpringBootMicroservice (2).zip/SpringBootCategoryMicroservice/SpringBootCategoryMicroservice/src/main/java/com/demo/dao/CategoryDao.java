package com.demo.dao;

import com.demo.beans.Category;

public interface CategoryDao {

	Category getCategoryById(int cid);

}
