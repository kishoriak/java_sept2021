package com.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.demo.beans.Product;

@Repository
public class ProductDaoImpl implements ProductDao{

	@Autowired
	 JdbcTemplate jdbcTemplate;

	@Override
	public List<Product> getAllProductBycategoryId(int cid) {
		String sql="select * from producthsbc where catid=?";
		return jdbcTemplate.query(sql, new Object[] {cid},(rs,num)->{
			Product p=new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setQty(rs.getInt(3));
			p.setPrice(rs.getDouble(4));
			p.setMfgdate(rs.getDate(5).toLocalDate());
			p.setCatid(rs.getInt(6));
			return p;
		});
	}
}
