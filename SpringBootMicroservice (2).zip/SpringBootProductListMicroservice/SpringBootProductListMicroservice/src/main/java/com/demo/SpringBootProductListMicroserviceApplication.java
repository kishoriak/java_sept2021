package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProductListMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductListMicroserviceApplication.class, args);
	}

}
