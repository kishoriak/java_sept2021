package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.beans.Product;
import com.demo.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/product/{cid}")
	public ResponseEntity<List<Product>> getProductListByCategory(@PathVariable int cid){
		List<Product> plist=productService.getAllProductByCategoryId(cid);
		if(plist.size()!=0) {
			return ResponseEntity.ok(plist);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}

}
