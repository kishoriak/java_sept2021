package com.demo.exception;

public class StudentNotCreatedException extends Exception {
	
	public StudentNotCreatedException(String message) {
		super(message);
	}
	public StudentNotCreatedException(String msg,Throwable e) {
		super(msg,e);
		
	}
	
}
