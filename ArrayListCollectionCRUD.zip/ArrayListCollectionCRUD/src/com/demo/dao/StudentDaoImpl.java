package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Student;
import com.demo.exception.StudentNotFoundException;

public class StudentDaoImpl implements StudentDao{
	
	private static List<Student> slist;

	static {
		slist = new ArrayList<>();
	}
	

	@Override
	public void saveStudent(Student student) {
		slist.add(student);
		
	}


	@Override
	public List<Student> getAll() {
		return slist;
	}


	@Override
	public Student findById(int id) throws StudentNotFoundException {
		/*for(Student s:slist) {
			if(s.getSid()==id) {
				return s;
			}
		}*/
		int pos=slist.indexOf(new Student(id));
		if(pos==-1) {
			throw new StudentNotFoundException("Student not found");
		}
		else {
			return slist.get(pos);
		}
	}

}
