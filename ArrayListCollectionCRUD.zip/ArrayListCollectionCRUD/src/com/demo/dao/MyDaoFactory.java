package com.demo.dao;

public class MyDaoFactory {

	public static StudentDao getStudentDao() {
		
		return new StudentDaoImpl();
	}

}
