package com.demo.dao;

import java.util.List;

import com.demo.beans.Student;
import com.demo.exception.StudentNotFoundException;

public interface StudentDao {

	void saveStudent(Student student);

	List<Student> getAll();

	Student findById(int id) throws StudentNotFoundException;

}
