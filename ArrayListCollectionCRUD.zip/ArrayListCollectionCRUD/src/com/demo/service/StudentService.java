package com.demo.service;

import com.demo.beans.Student;
import com.demo.exception.NoNegativeMarksException;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotCreatedException;
import com.demo.exception.StudentNotFoundException;

public interface StudentService {

	void addStudent() throws StudentNotCreatedException, StudentExistsException, StudentNotFoundException ;

	void displayAll();

	//void writedata();

	//void readData();

	Student searchById(int id) throws StudentNotFoundException;

}
