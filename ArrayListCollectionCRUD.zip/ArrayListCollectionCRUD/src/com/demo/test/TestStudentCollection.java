package com.demo.test;
import java.util.Scanner;
import java.util.stream.Stream;

import com.demo.beans.Student;
import com.demo.exception.StudentExistsException;
import com.demo.exception.StudentNotCreatedException;
import com.demo.exception.StudentNotFoundException;
import com.demo.service.StudentService;
import com.demo.service.StudentServiceImpl;

public class TestStudentCollection {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		StudentService ss=new StudentServiceImpl();
		int choice=0;
		do {
		System.out.println("1.Add new student\n2. search by id\n3.search by name\n");
		System.out.println("4. display all\n5. sort by name\n6. delete by id\n7.update marks by id\n8.exit\n");
		System.out.println("choice :");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			try {
				ss.addStudent();
			} catch (StudentNotCreatedException | StudentExistsException | StudentNotFoundException e) {
				System.out.println(e.getMessage());
			}
			
			break;
		case 2:
			System.out.println("enetr id");
			int id=sc.nextInt();
			try {
				Student s=ss.searchById(id);
			} catch (StudentNotFoundException e) {
				System.out.println(e.getMessage());
			}
			
			break;
		case 3:
			
			break;
		case 4:
			ss.displayAll();
			break;
		case 5:
			
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			
			break;
		}
		
		}while(choice!=8);
	}

}
