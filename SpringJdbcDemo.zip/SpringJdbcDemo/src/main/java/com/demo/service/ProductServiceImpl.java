package com.demo.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.beans.Product;
import com.demo.dao.ProductDao;

@Service("pservice")
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao pdao;

	public void addProduct() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enetr id");
		int pid=sc.nextInt();
		System.out.println("enetr name");
		String nm=sc.next();
		System.out.println("enetr qty");
		int qty=sc.nextInt();
		System.out.println("enetr price");
		double pr=sc.nextDouble();
		System.out.println("enetr date(dd-MM-yyyy");
		String dt=sc.next();
		LocalDate ldt=LocalDate.parse(dt, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		Product p=new Product(pid,nm,qty,pr,ldt);
		pdao.save(p);
		
		
	}

	@Override
	public List<Product> getAllProduct() {
		return pdao.findAll();
	}

	@Override
	public Product getById(int id) {
		return pdao.findById(id);
	}

	@Override
	public int updateProduct(int id, int qty, double price) {
		return pdao.updateById(id,qty,price);
	}

}
