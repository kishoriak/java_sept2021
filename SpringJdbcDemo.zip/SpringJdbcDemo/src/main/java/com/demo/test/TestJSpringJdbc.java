package com.demo.test;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.Product;
import com.demo.service.ProductService;

public class TestJSpringJdbc {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("springcfg.xml");
        ProductService pservice=(ProductService)ctx.getBean("pservice");
        Scanner sc=new Scanner(System.in);
        int choice=0;
        do {
        System.out.println("1. Add product\n2. delete product\n3.update product\n4. display all product\n5. display by id");
        System.out.println("6. display product in range\n 7.exit");
        System.out.println("enetr choice");
        choice=sc.nextInt();
        switch(choice) {
        case 1:
        	pservice.addProduct();
        	break;
        case 2:
        	break;
        case 3:
        	System.out.println("enetr id");
        	int id=sc.nextInt();
        	System.out.println("enetr qty");
        	int qty=sc.nextInt();
        	System.out.println("enetr price");
        	double price=sc.nextDouble();
        	int n=pservice.updateProduct(id,qty,price);
        	if(n>0) {
        		System.out.println("updation done!!");
        	}
        	else {
        		System.out.println("not found");
        	}
        			
        	break;
        case 4:
        	List<Product> plist=pservice.getAllProduct();
        	plist.stream().forEach(System.out::println);
        	break;
        case 5:
        	System.out.println("enetr id");
        	int id=sc.nextInt();
        	Product p=pservice.getById(id);
        	System.out.println(p);
        	break;
        case 6:
        	break;
        case 7:
        	System.out.println("Thank you for visiting, Do visit again.....");
        	break;	
        }
        }while(choice!=7);
	}

}
