package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao {

	void save(Product p);

	List<Product> findAll();

	Product findById(int id);

	int updateById(int id, int qty, double price);

}
