package com.demo.streamAPI;

import java.util.Optional;

public class OptinalClassDemo {
	public static void main(String[] args) {
		//Optional<String> op=Optional.of("test");
		Optional<String> op=Optional.empty();
		//System.out.println(op.get());  //thorws NoSuchelementException
		System.out.println(op.orElse("other"));
		System.out.println(op.orElseGet(()->"other"));
		
		/*Optional<String> op1=Optional.of("testing");
		System.out.println(op1.get());  //thorws NoSuchelementException
		
		Optional<String> opempty=Optional.empty();
		  System.out.println(op.orElse("Happy")); ///Happy
		  
		  Optional<String> opempty1=Optional.empty();
		  String result=opempty1.orElseGet(()->"testing");
		  System.out.println(result);  // prints testing*/

		  Optional<String> op11=Optional.empty();
		  op11.ifPresent(System.out::println); 
		  Optional<Integer> op112=Optional.of(1);
		  Optional<Integer> opfil= op112.filter(i->i%2==0); // no value will be 
		  //selected from op, so the object opfil is empty
		  System.out.println(opfil.isPresent()); // prints false
		  
		/*  Optional<Integer> len=op.map(String::length);
		  System.out.println(len);   // return empty optional object
		  
		  Optional<Integer> len1=op.map(String::length);
		  System.out.println(len);
		  
		  
		  Optional<String> oplower=Optional.of("test");
		  Optional<String> opupper=oplower.flatMap(s->Optional.of(s.toUpperCase()));
		  System.out.println(opupper.get());  */




	}

}
