package com.demo.streamAPI;

import java.util.OptionalDouble;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class TestStudentCollect {

	public static void main(String[] args) {
		
			Student s1=new Student("Raj");
			Student s2=new Student("Anil");
			s1.addMarks(8.0);
			Stream<Double> ms=s1.getMarks().stream();

			Stream.of(s1).flatMapToDouble(s-> ms.mapToDouble(Double::doubleValue))
			.forEach(System.out::println); //line1

			ms.forEach(System.out::println);  //line2
			
			Stream<Double> stream=Stream.of(1.0,2.0,3.0);
			DoubleStream s=DoubleStream.of(1.0,2.0,3.0);
			OptionalDouble ans=s.average();//line1
			System.out.println(ans);

			

	}

}
