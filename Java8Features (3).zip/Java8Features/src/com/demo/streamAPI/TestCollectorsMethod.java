package com.demo.streamAPI;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.demo.model.Product;

public class TestCollectorsMethod {

	public static void main(String[] args) {
		/*Stream<String> s1=Stream.of("aA","bb","cc","dd","xxx","cc","dd");
		//List<String> slist=s1.filter(s->s.length()<3).collect(Collectors.toList());
		Set<String> slist=s1.filter(s->s.length()<3).collect(Collectors.toSet());
		System.out.println(slist);*/
		
		/*Stream<String> s2=Stream.of("aA","bb","cc","dd","xxx");
		List<String> sset=s2.filter(s->s.length()<3).collect(Collectors.toList());
		System.out.println(sset);*/
		
		/*Stream<String> s3=Stream.of("aA","bb","cc","dd","xxx");
        LinkedList<String> list=s3.collect(Collectors.toCollection(()->new LinkedList<>()));
        System.out.println(list);*/
        
        
        Stream<Product> sprod=Stream.of(new  Product("chair",3000.00), new  Product("Table",5000.00));
        //Map<String,Double> map=sprod.collect(Collectors.toMap(Product::getName, Product::getPrice));
        Map<String,Double> map=sprod.collect(Collectors.toMap(p->p.getName(), p->p.getPrice()));
        System.out.println(map);

	}

}
