package com.demo.streamAPI;

import java.util.stream.Stream;

public class TesMapPeek {

	public static void main(String[] args) {
		Stream<String> stream=Stream.of("Java","Python");
		stream.map(s->{System.out.println(s.toUpperCase()); return s.toUpperCase();}).forEach(s->{System.out.println(s); });


	}

}
