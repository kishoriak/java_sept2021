package com.demo.streamAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class TestflatMap {
	public static void main(String[] args) {
		Player p1=new Player("Sachin",20,"allrounder");
		Player p2=new Player("Rahul",19,"batsman");
		Player p3=new Player("Ashwin",17,"bowler");
		Player p4=new Player("Raina",17,"allrounder");
		Team t1=new Team("Team1");
		t1.addplayer(p1);
		t1.addplayer(p2);
		
		Team t2=new Team("Team2");
		t2.addplayer(p3);
		t2.addplayer(p4);
		
		List<Team> tlist=new ArrayList<>();
		tlist.add(t1);
		tlist.add(t2);
		
		Stream<Player> pstream=tlist.stream().flatMap(t->t.getPlayers().stream());
		List<Stream> slist=tlist.stream().map(t->t.getPlayers().stream()).collect(Collectors.toList());
		pstream.forEach(System.out::println);
		
		IntStream is=tlist.stream().flatMapToInt(c->c.getPlayers().stream().mapToInt(Player::getExp));
		//Stream<String> ns=tlist.stream().flatMap(c->c.getPlayers().stream().map(p->p.getName()));
	
		
				
		is.forEach(System.out::println);		
		
		
		Stream<String> s1=Stream.of();
		s1.map(s->s.length()).forEach(System.out::println);
		
		
		//to calculate average experience of each speacialization
		Stream<Player> pstream1=tlist.stream().flatMap(t->t.getPlayers().stream());
		Map<String,Double> pmapexp=pstream1.collect(Collectors.groupingBy(Player::getSpecial,Collectors.averagingDouble(Player::getExp)));
		System.out.println(pmapexp);
		
		
	}

}
