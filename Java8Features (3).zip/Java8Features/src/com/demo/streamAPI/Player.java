package com.demo.streamAPI;

public class Player {
	private String name;
	private int exp;
	private String special;
	public Player(String name, int exp,String s) {
		super();
		this.name = name;
		this.exp = exp;
		this.special=s;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	
	public String getSpecial() {
		return special;
	}
	public void setSpecial(String special) {
		this.special = special;
	}
	@Override
	public String toString() {
		return "Player [name=" + name + ", exp=" + exp + ", special=" + special + "]";
	}
	
	

}
