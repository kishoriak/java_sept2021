package com.demo.streamAPI;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestCollector {

	public static void main(String[] args) {
		Stream<String> sstream=Stream.of("a","b","c","d","c");
		List<String> list=sstream.collect(Collectors.toList());
		System.out.println(list);
		
		Stream<String> sstream1=Stream.of("a","b","c","d","c");
		Set<String> set=sstream1.collect(Collectors.toSet());
		System.out.println(list);
		

	}

}
