package com.demo.streamAPI;

import java.util.Optional;
import java.util.stream.Stream;

import com.demo.functionalinterfaces.test.Person;

public class TestClass2 {
	public static void main(String[] args) {
		Person p1=new Person("Rajan",20,Person.Gender.MALE);
		Person p2=new Person("Yash",65,Person.Gender.MALE);
		Person p3=new Person("Ashu",22,Person.Gender.MALE);
		Stream<Person> sper=Stream.of(p1,p2,p3);
		
		Optional<Person> op=sper.findFirst();  //returns first element
		System.out.println(op.get().getName());
			
		sper=Stream.of(p1,p2,p3);
		op=sper.findAny();  //returns random element
		System.out.println(op.get().getName());
	}

}
