package com.demo.streamAPI;

import java.util.ArrayList;
import java.util.List;

public class Student{
    private String name;
    private List<Double> marks=new ArrayList<>();
public Student(String cn){
  this.name=cn;
  }
public void addMarks(double m){
   this.marks.add(m);
}
public String getName(){
  return name;
}
public List<Double> getMarks(){
  return marks;
} 
}
