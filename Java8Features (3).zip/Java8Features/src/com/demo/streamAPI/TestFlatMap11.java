package com.demo.streamAPI;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestFlatMap11 {

	public static void main(String[] args) {
		 String[][] array = new String[][]{{"a", "b"}, {"c", "d"}, {"e", "f"}};

		  // array to a stream
		  Stream<String[]> stream1 = Arrays.stream(array);

		  // same result
		  Stream<String[]> stream2 = Stream.of(array);
		  //-------------------------------------------
		  
		 /* String[][] array = new String[][]{{"a", "b"}, {"c", "d"}, {"e", "f"}};

		  // convert array to a stream
		  Stream<String[]> stream1 = Arrays.stream(array);

		  List<String[]> result = stream1
		      .filter(x -> !x.equals("a"))      // x is a String[], not String!
		      .collect(Collectors.toList());

		  System.out.println(result.size());    // 0

		  result.forEach(System.out::println);  // print nothing? */
		  
		  //---------------------------------------
		  
		/*  String[][] array = new String[][]{{"a", "b"}, {"c", "d"}, {"e", "f"}};

		  List<String> collect = Stream.of(array)     // Stream<String[]>
		          .flatMap(Stream::of)                // Stream<String>
		          .filter(x -> !"a".equals(x))        // filter out the a
		          .collect(Collectors.toList());      // return a List

		  collect.forEach(System.out::println);*/

	}

}
