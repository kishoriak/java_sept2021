package com.demo.streamAPI;

import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class TestCalculationReduction {

	public static void main(String[] args) {
		Stream.empty()
		/*Stream<String> s=Stream.of("a","b","c");
		long count=s.count();  //return type of method count is same in generic and primitive type interface
		System.out.println(count);  //3
		
		Collection<Integer> source=Arrays.asList(3,1,2,4,5,6);
		Stream<Integer> s1=source.stream();
		//Generic class method accepts comparator as parameter
		Optional<Integer> min=s1.min(Integer::compare);
		System.out.println("Minimum : "+min.get());
		
		Stream<Integer> s2=source.stream();
		//Generic class method accepts comparator as parameter
		Optional<Integer> max=s2.max(Integer::compare); 
		IntStream is=IntStream.range(5, 20);
		//Primitive interface min and max doesnot need comaparator object
		OptionalInt min1=is.min();
		
		Stream<String> ss=Stream.of("xxx","abc");
		Optional<String> max1=ss.max(String::compareTo);
		System.out.println(max1.get());

		
		Stream<Integer> s3=source.stream();
		Optional<Integer> result=s3.reduce(Integer::sum);  
		System.out.println(result.get());*/
		Collection<Integer> source=Arrays.asList(3,1,2,4,5,6);
		Stream<Integer> s4=source.stream();
		//this reduce method returns result of same type as data of the stream
		//Primitive interface reduce function return result of their respective types.
		int result1=s4.reduce(1,(a,b)->a*b); 
		
		System.out.println(result1);
		Stream<Integer> s5=source.stream();
		Optional<Integer> res=s4.reduce((a,b)->a*b);
		System.out.println(res.orElse(10));
		
		/*Stream<String> ss1=Stream.of("xxx","abc");
		
		//Optional<String> result12=ss1.reduce((a,b)->a+b); //conactenates Strings
		String result12=ss1.reduce("aaa",(a,b)->a+b);
		System.out.println(result12);
		//System.out.println(result12.get());*/
		
		//average and sum methods works only with primitive streams
		IntStream is1=IntStream.range(5, 20);
		OptionalInt m=is1.min();
		OptionalDouble avg=is1.average();
		
		double average=avg.getAsDouble();
		System.out.println("average "+average);
		
		
		DoubleStream ls=DoubleStream.generate(()->java.lang.Math.random()).limit(10);
		double sum=ls.sum();
		
		System.out.println(sum);

	}

}
