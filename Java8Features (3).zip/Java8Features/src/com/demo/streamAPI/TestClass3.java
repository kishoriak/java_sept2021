package com.demo.streamAPI;

import java.util.function.Predicate;
import java.util.stream.Stream;

import com.demo.functionalinterfaces.test.Person;

public class TestClass3 {
	public static void main(String[] args) {
		Person p1=new Person("Rajan",20,Person.Gender.MALE);
		Person p2=new Person("Yash",65,Person.Gender.MALE);
		Person p3=new Person("Ashu",22,Person.Gender.MALE);
		
		Predicate<Person> p=s->s.getAge()>25;
		
		Stream<Person> sper=Stream.of(p1,p2,p3);
		
		System.out.println(sper.anyMatch(p)); //true
		
         sper=Stream.of(p1,p2,p3);
		
		System.out.println(sper.allMatch(p)); //false
		
		sper=Stream.of(p1,p2,p3);
		
		System.out.println(sper.noneMatch(p)); //false
		
		Stream<String> s=Stream.of();
		boolean result=s.allMatch(s1->{System.out.println("in predicate");
		return s1.equals("Hello");});
		System.out.println(result);

		
	}

}
