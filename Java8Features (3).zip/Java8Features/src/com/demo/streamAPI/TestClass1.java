package com.demo.streamAPI;

import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.demo.functionalinterfaces.test.Person;

public class TestClass1 {

	public static void main(String[] args) {
		Person p1=new Person("Rajan",20,Person.Gender.MALE);
		Person p2=new Person("Yash",65,Person.Gender.MALE);
		Person p3=new Person("Ashu",22,Person.Gender.MALE);
		Stream<Person> sper=Stream.of(p1,p2,p3);
		Stream<Person> s2=sper.peek(p->System.out.println(p.getName()+ "  "+p.getAge()));//this will not run till we write terminal API
		s2.forEach(p->{System.out.println(p);}); // this is printing person object, used only for executing intermidiate API peek
		//s2.forEach(p->{}) // does nothin but used  only for executing intermediate API peek
		sper=Stream.of(p1,p2,p3);
		//converts person objects from stream to String
		Stream<String> sname=sper.map(Person::getName);
		sname.forEach(System.out::println);
		
		sper=Stream.of(p1,p2,p3);
		//primitive stream
		
		
		IntStream ages=sper.mapToInt(Person::getAge);
		ages.forEach(System.out::println);
		 
		
		
		
		

	}

}
