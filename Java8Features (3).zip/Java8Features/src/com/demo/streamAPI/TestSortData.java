package com.demo.streamAPI;

import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

public class TestSortData {

	public static void main(String[] args) {
		Collection<Integer> source=Arrays.asList(3,1,2,4,5,6);
		Stream<Integer> ss=source.stream().sorted();
		//forEachOrdered maintains the order of the stream if it is predefined
		ss.forEachOrdered(System.out::println); 
		
		//elements are sorted based on length
		
				Stream<String> ss2=Stream.of("xc","aaa","bxc").sorted((s1,s2)->s1.length()-s2.length());
				Optional<String> result=ss2.reduce(String::concat);
				System.out.println(result);
	}

}
