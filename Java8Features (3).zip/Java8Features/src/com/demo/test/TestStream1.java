package com.demo.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class TestStream1 {

	public static void main(String[] args) {
		List<Integer> numlist=Arrays.asList(1,2,3,4,5,6);
		Stream<Integer> stream=numlist.stream();
		stream.filter(i->i%2==0).map(i->i*2).forEach(s->System.out.println(s));
        
		
		Stream<String> names=Stream.of("Kishori","Kanchan","Rajan","Anil","Rashmi");
		names.filter(s->{System.out.println(s); return s.length()>5;});//.foraEach(s->Syatem.out.println(s));
		
		
		Stream<String> nums=Stream.of("aaa","bbb","ccccc","dddddd");
		//no string matches condition so no o/p
		nums.filter(s->{/*System.out.print("In filter"+s);*/return s.length()>10;}).forEach(s-> System.out.println(s));
		//nums.forEach(s-> System.out.println(s));

		
		
	}

}
