package com.demo.test;

public class Demo1
{
   public static void main(String[] args)
    {
        char x[] = {'a','b','c','d','e'};
        for (char c : x) {
                System.out.print(x[0]+""+c);
        }    
    }
}

