package com.demo.test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.demo.model.Product;
import com.demo.model.ProductFinder;

public class TestMethodReference {

	public static void main(String[] args) {
		Stream<Double> stream=Stream.of(.05,0.20);
		List<Product> plist=new ArrayList<>();
		plist.add(new Product("chair",3000.45));
		plist.add(new Product("Table",15000.45));
		plist.add(new Product("Shelf",3000.45));
		plist.add(new Product("Lampshade",1000.45));
		plist.stream().forEach(p->Product.productcode(p));
		//if the method is static method then the stream object will be passed as a parameter
		plist.stream().forEach(Product::productcode);
		Stream s=plist.stream().filter(p->p.isPremium());//.forEach(System.out::println);
		//s.forEach(System.out::println);
		//plist.stream().count();
		System.out.println(s.count());
		//in filter since we are just calling instance method so can be replaced by method reference
		//if the method is instance method then the instance will be passed as this parameter
		plist.stream().filter(Product::isPremium).forEach(System.out::println);
		
		ProductFinder pf=new ProductFinder();
		//plist.stream().sorted((p1,p2)->pf.finder(p1,p2)).forEach(s->System.out.println(s));
		//this can be replaced by method reference
		plist.stream().sorted(pf::finder).forEach(System.out::println);
		
		/*Stream s1=plist.stream().filter(p->{System.out.println("in filter"+p.getName());
		                                    return p.isPremium();});
		System.out.println("before printing filter output");
		s1.forEach(p->{System.out.println("in forEach");System.out.println(p);}*/);
		
		
		
	}

}
