package com.demo.test;

import java.util.Optional;
import java.util.stream.Stream;

public class TestMatchFunction {

	public static void main(String[] args) {
		/*Stream<String> ss=Stream.of("Ashu","Kishori","Ashutosh","Rajan");
		boolean ans=ss.anyMatch(s->{System.out.println(s);return s.startsWith("L");});
        System.out.println(ans);*/
        
       /* Stream<String> ss1=Stream.of("Ashu","Kishori","Ashutosh","Rajan");
        boolean ans=ss1.allMatch(s->{System.out.println(s);return s.length()>4;});
        System.out.println(ans);*/
        
       /* Stream<String> ss1=Stream.of("Ashu","Kishori","Ashutosh","Rajan");
        boolean ans=ss1.noneMatch(s->{System.out.println(s);return s.length()>4;});
        System.out.println(ans);*/
        
        Stream<String> ss1=Stream.of("Ashu","Kishori","Ashutosh","Rajan");
        Optional<String> op=ss1.findAny();
        if (op.isPresent()) {
            System.out.println(op.get());
        }else {
        	System.out.println("not found");
        }
	}

}
