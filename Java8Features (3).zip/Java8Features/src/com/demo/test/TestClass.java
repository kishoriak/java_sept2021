package com.demo.test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestClass {

	public static void main(String[] args) {
		List<Integer> last=new ArrayList<>();
		last.add(23);
		
		
		ArrayDeque<String> adeque=new ArrayDeque<>();
		adeque.add("B");           
		adeque.add("A");  
		adeque.add("C");
		adeque.addFirst("g");
		//adeque.peek();
		adeque.poll();
		Iterator<String> it=adeque.iterator();
		while(it.hasNext()){
		   System.out.println(it.next());
		}


	}

}
