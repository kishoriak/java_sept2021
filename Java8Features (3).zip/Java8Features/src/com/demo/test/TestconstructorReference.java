package com.demo.test;

import java.util.stream.Stream;

import com.demo.model.MyModel;

public class TestconstructorReference {
	public static void main(String[] args) {
		Stream<Integer> stream=Stream.of(1,2,3);
		//Stream<MyModel> mlist=stream.map(p->new MyModel(p));
		Stream<MyModel> mlist=stream.map(MyModel::new);
		//Stream<MyModel> mlist1=Stream.generate(MyModel::new).limit(3);
		//System.out.println(mlist1.count());
		System.out.println(mlist.count());
	}
	
}
