package com.demo.test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Comparator;
import com.demo.model.Student;

public class TestFilter {
public static void main(String[] args) {
	List<Integer> lst=new ArrayList<>();  ///ordered collection
	for(int i=1;i<20;i++) {
		lst.add(i);
	}
	for(Integer i:lst) {
		if(i%2==0) {
			System.out.println(i);
		}
	}
	
	Stream<Integer> si=lst.stream();
	//si.map(s->s*s).forEach(System.out::println);
	List<Integer> s2=si.map(s->s*s).collect(Collectors.toList());
	//stream function 2 types intermidiate terminating stream functions
	si=lst.stream();
	//find* ----findFirst, findAny
	//*Match----- allMatch,anyMatch,noneMatch
	si.filter(s->{System.out.println("in filter ");return s%2==0;}).findAny();
	
	lst.stream().count();
	
	
	Stream<Integer> ssi=Stream.of(1,2,3,4,5);
	ssi.forEach(System.out::println);
	
	//lst.stream().filter(s-> s%2==0 && s>5 ).forEach(System.out::println);
	
	//System.out.println("before forEach");
	//s1.forEach(f->{System.out.println(f);});
	//System.out.println("after forEach");
	/*lst.stream().filter(s->s%2==0).forEach(System.out::println);
	
	for(Integer i:lst) {
		
			System.out.println(i*i);
		
	}
	
	
	lst.stream().map(i->i*i).forEach(System.out::println);
	
	
	
	
	List<Student> slist=new ArrayList<>();
	slist.add(new Student(12,"aaa",34,33,33));
	slist.add(new Student(13,"bbb",24,23,33));
	slist.add(new Student(14,"ccc",35,33,33));
	slist.add(new Student(15,"ddd",34,32,33));
	slist.add(new Student(16,"fff",31,31,33));
	slist.removeIf(s->s.getName().startsWith("a"));
	for (Object stud:slist){
	   System.out.println(((Student)stud).getName());
	}

	/*for(Student s:slist) {
		
			System.out.println(s);
		
	}
	slist.forEach(s->{System.out.println(s);});
	
	slist.forEach(System.out::println);
	
	
	for(Student s:slist) {
		if(s.getM1()>32) {
			System.out.println(s);
		}
	}
	
	Comparator<Student> cmp1=(s,t)->{return s.getName().compareTo(t.getName());};
	
	slist.stream().filter(s->s.getM1()>32).forEach(System.out::println);
	slist.stream()
	.filter(s->s.getM1()>32)
	.min(cmp1)
	.ifPresent(System.out::println);
	
	LocalDate lt=LocalDate.now();
	System.out.println(lt);
	
	//to retrieve part of date day, month and year
	int dd=lt.getDayOfMonth();
	int mm=lt.getMonthValue();
	int yy=lt.getYear();
	System.out.printf("%d-%d-%d\n",dd,mm,yy);
	System.out.printf("%d/%d/%d\n",dd,mm,yy);
	Scanner sc=new Scanner(System.in);
	int yy1=sc.nextInt();
	int mm1=sc.nextInt();
	int dd1=sc.nextInt();
	LocalDate lt1=LocalDate.of(yy1, mm1, dd1);
	System.out.println(lt1);*/
}
}
