package com.demo.test;

import java.util.function.Function;
import java.util.function.Predicate;

import com.demo.service.GenericInterface;
import com.demo.service.Interface123;
import com.demo.service.MyClass;
import com.demo.service.MyServeiceImpl;

public class TestInterface {

	public static void main(String[] args) {
		MyServeiceImpl ob=new MyServeiceImpl();
		ob.m2();
		ob.m1();
		ob.m3();

		Interface123<Integer> ob1=s->{System.out.println(s);};
		ob1.m4(4);
		
		Predicate<Integer> p1=s->{
			if(s>5)
				return true;
			else
				return false;
		};
	
      p1.test(6);
      
      
      GenericInterface<Integer,Integer> ob11=(a,b)->{
    	  if(a>b)
    		  return a;
    	  else 
    		  return b;
      };
      
      System.out.println("Maximum : "+ob11.compareMax(12,15));
      
      GenericInterface<Integer,String> ob12=(a,b)->{
    	  if(a.length()>b.length())
    		  return a.length();
    	  else 
    		  return b.length();
      };
      System.out.println("length : "+ob12.compareMax("Hello4567","Enjoy11"));
     
      
      Function<String,Integer> f1=s12->{return s12.length();};
      System.out.println("Length from function interface"+f1.apply("hjdhfdjkshd"));
	}
}
