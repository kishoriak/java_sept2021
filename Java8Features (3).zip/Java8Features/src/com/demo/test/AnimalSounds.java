package com.demo.test;

abstract class Animal{
	abstract void getSound();
}

class Cat extends Animal{
	void getSound(){
		System.out.println("Meow");
	}
}
	
class Dog extends Animal{
	void getSound(){
		System.out.println("bowWow");
	}
}

public class AnimalSounds{
	public static void main(String[] args) {
		Animal c = new Cat();
		c.getSound();
	}
}
