package com.demo.test;

class Crick{
    public String display(){
        return "Crick";
    }
}
class Buzz extends Crick{
    public String display(){
        return super.display()+"Buzz";
    }
}

class Fuzz extends Crick{
    public String display(){
        return super.display()+"Fuzz";
    }
}

public class Demo
{
   public static void main(String[] args)
    {
        Fuzz f = new Fuzz();
        System.out.print(f.display());
    }
}

