package com.demo.primitiveinterfaces;

import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class TestIntPredicate {

	public static void main(String[] args) {
		IntPredicate ip=i->{
			// i is int type and not Integer type because its a primitive interface
			// boxing will not happen // this will not compile
			//System.out.println(i instanceof Integer); // this will not compile
			return i>0;
		};
		
		Predicate<Integer> genricpredicate=i->{
			System.out.println(i instanceof Integer); //returns true
			return i>0;
		};

	}

}
