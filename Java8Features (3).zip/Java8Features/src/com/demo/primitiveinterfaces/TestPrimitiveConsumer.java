package com.demo.primitiveinterfaces;

import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

public class TestPrimitiveConsumer {
	public static void main(String[] args) {
		//intVal method is from Double wrapper class and cannot be called here its compile time error
		//autoboxing is not possible for primitice type interfaces
		//DoubleConsumer dc=d->{ System.out.println(d.intValue());};
		Consumer<Double> dc1=d->{ System.out.println(d.intValue());};
	}
	

}
