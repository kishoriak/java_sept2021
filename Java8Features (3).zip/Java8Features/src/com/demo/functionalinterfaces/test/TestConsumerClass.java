package com.demo.functionalinterfaces.test;

import java.util.function.Consumer;

public class TestConsumerClass {
	public static void checkValidity(Person p,Consumer<Person> c) {
		c.accept(p);
	}

	public static void main(String[] args) {
		Consumer<Person> setStatus=p->{
			if(p.getAge()>=18 && p.getAge()<=60) {
			   p.setStatus("Accepted");	
			}
			
		};
        Consumer<Person> notify=p->{
        	if(p.getStatus().equals("Accpeted"))
        		System.out.println(p.getName()+"Accepted");
        };
        Person p1=new Person("Rajan",20,Person.Gender.MALE);
		Person p2=new Person("Yash",65,Person.Gender.MALE);
		Person p3=new Person("Ashu",22,Person.Gender.MALE);
		checkValidity(p1,setStatus.andThen(notify));
		checkValidity(p2,setStatus.andThen(notify));
		checkValidity(p3,setStatus.andThen(notify));
	}

}
