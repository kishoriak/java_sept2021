package com.demo.functionalinterfaces.test;

import java.util.function.Predicate;

public class TestClass {
	public static void verifyPerson(Person p,Predicate<Person> pred) {
		if(pred.test(p)) 
			System.out.println(p.getAge()+"is valid"+p.getName()+"Accepted");
		else
			System.out.println(p.getName()+"is rejected");
	}
	
	public static void main(String[] args) {
		Predicate<Person> isValidAge=p->p.getAge()>=18 && p.getAge()<=60;
		Predicate<Person>  isMale=p->p.getGender()==Person.Gender.MALE;
		Predicate<Person> isValid=isMale.and(isValidAge);
		Person p1=new Person("Rajan",20,Person.Gender.MALE);
		Person p2=new Person("Yash",65,Person.Gender.MALE);
		Person p3=new Person("Ashu",22,Person.Gender.MALE);
		verifyPerson(p1,isValid);
		verifyPerson(p2,isValid);
		verifyPerson(p3,isValid);
	}

}
