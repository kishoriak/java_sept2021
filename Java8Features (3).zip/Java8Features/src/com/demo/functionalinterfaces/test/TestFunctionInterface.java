package com.demo.functionalinterfaces.test;

import java.util.function.Consumer;
import java.util.function.Function;

public class TestFunctionInterface {
	public static void handlePerson(Person p,Function<Person,String> fp) {
		String result=fp.apply(p);
		System.out.println(p.getName()+" is "+result);
	}

	public static void main(String[] args) {
		Function<Person,Person> setStatus=p->{
			if(p.getAge()>=18 && p.getAge()<=60) {
				   p.setStatus("Accepted");
				   
				}
			return p;
			};
			
			Function<Person,String> returnResult=p->{
				if (p.getStatus().equals("Accepted"))
					return "Accepted";
				else
					return "Rejected";
						
			};
			Person p1=new Person("Rajan",20,Person.Gender.MALE);
			Person p2=new Person("Yash",65,Person.Gender.MALE);
			Person p3=new Person("Ashu",22,Person.Gender.MALE);
			handlePerson(p1,returnResult.compose(setStatus));
			handlePerson(p1,setStatus.andThen(returnResult));

	}

}
