package com.demo.service;

public class MyClass implements Interface123<Integer> {

	@Override
	public void m4(Integer c) {
		System.out.println("In M4 method"+c);
		
	}
	

}
