package com.demo.service;

public class MyServeiceImpl implements MyInterface1,MyInterface2{

	@Override
	public void m3() {
		System.out.println("in m3 in class");
		
	}
	

	
	public void m1() {
		System.out.println("in m1 in class");
	};

	public void m2() {
		//MyInterface1.super.m2();
		//MyInterface2.super.m2();
		System.out.println("in Class m2");
	 
    }
	
}
