package com.demo.service;


@FunctionalInterface
public interface GenericInterface<R,T> {
      R  compareMax(T a,T b);
}
