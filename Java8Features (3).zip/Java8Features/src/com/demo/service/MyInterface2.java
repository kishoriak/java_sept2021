package com.demo.service;

public interface MyInterface2 {
	void m1();
	default void m2() {
		System.out.println("in myInterface2 method 2");
	}
	void m3();

}
