package com.demo.service;

public interface Interface123<R> {
   void m4(R c);
}
