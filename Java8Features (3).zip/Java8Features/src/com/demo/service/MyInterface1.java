package com.demo.service;

public interface MyInterface1 {
	void m1();
	default void m2() {
		System.out.println("in myInterface1 method 2");
	}

}
