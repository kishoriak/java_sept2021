package com.demo.dates;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.MonthDay;
 import java.time.Year;
import java.time.ZoneId;
import java.time.ZonedDateTime;

 public class MyClass{
 public static void main(String[] args){
 Year y = Year.of(2014);
 //LocalDate date = y.now(); //Assume current date 2015-01-01
 Year d=y.now();
 
/* System.out.println(d);
 LocalDate ld1 = LocalDate.of(2015,11,25);
 Year year = Year.of(2014);
 System.out.println(ld1.adjustInto(year.atDay(1)));*/
 ZoneId zid=ZoneId.of("Europe/Paris");
	LocalDateTime lForwardDST=LocalDateTime.of(2018, 3,25,2,30);  //dayligth started in paris at this date and time
	
	LocalDateTime lBackwordDST=LocalDateTime.of(2018, 10,28,2,30); // datlight stops at this date and time 
	
	ZonedDateTime zfwDST =ZonedDateTime.of(lForwardDST,zid);
	System.out.println("ZFWDST "+zfwDST); // 2018-03-25T03:30+02:00[Europ/paris] //because of daylight start the time shows 3:30
	
	ZonedDateTime zbkDST =ZonedDateTime.of(lBackwordDST,zid);
	System.out.println("ZFWDST "+zfwDST); // 2018-10-28T02:30+02:00[Europ/paris]  // see the differnce of 1 hr in 2:30 and 3:30
	
	ZonedDateTime zbkEarlier =zbkDST.withEarlierOffsetAtOverlap();   //to manage this overlap time you may use these functions
	ZonedDateTime zbkLater =zbkDST.withLaterOffsetAtOverlap();
	System.out.println("ZFWDSTbkEarlier "+zbkEarlier);
	System.out.println("ZFWDSTbkLater "+zbkLater);


 }
 }

