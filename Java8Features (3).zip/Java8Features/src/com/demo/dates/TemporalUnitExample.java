package com.demo.dates;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class TemporalUnitExample {

	public static void main(String[] args) {
		LocalDateTime dt1=LocalDateTime.of(2018,6,30,12,0);
		LocalDateTime dt2=dt1.minus(1,ChronoUnit.DECADES).plus(11,ChronoUnit.YEARS);
		System.out.println("dt2 : "+dt2);
		dt2=dt2.plus(10,ChronoUnit.HOURS).minus(30,ChronoUnit.MINUTES);
		System.out.println(dt2);
				

	}

}
