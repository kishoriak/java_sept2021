package com.demo.dates;

import java.time.Year;

public class CheckLeapYear {

	public static void main(String[] args) {
		Year y=Year.of(2010);
		System.out.printf("%d is leap year : %b",y.getValue(),y.isLeap());

	}

}
