package com.demo.dates;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class ZoneDateTimeExample {

	public static void main(String[] args) {
		LocalDateTime ldt=LocalDateTime.of(2021,02,20,15,0);
		ZoneId zid=ZoneId.of("America/Los_Angeles");
		ZonedDateTime zdt1=ZonedDateTime.of(ldt, zid);
		System.out.println(zdt1.getOffset());//-8
		ZonedDateTime zdt2=zdt1.withMonth(3).withDayOfMonth(29).withHour(12);
		System.out.println(zdt2.getOffset());//-7 because of daylight saving
		
		

	}

}
