package com.demo.dates;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class TemporalQuestions1 {

	public static void main(String[] args) {
		LocalDateTime ldt=LocalDateTime.of(2018,4,1,2,0);
		ZoneId zid=ZoneId.of("Australia/Sydney");
		ZonedDateTime zdt=ZonedDateTime.of(ldt, zid);
		Duration duration=Duration.parse("PT2H");
		DateTimeFormatter df=DateTimeFormatter.ofPattern("HH':'mm");
		String formatted=zdt.plus(duration).format(df);
		System.out.println(formatted);
		

	}

}
