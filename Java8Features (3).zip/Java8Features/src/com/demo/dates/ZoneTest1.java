package com.demo.dates;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ZoneTest1 {

	public static void main(String[] args) {
		ZoneId z=ZoneOffset.of("Z");
		System.out.println(z);
		/*ZonedDateTime zdt=ZonedDateTime.parse("2021-06-30T12:20:30+02:00");
		DateTimeFormatter df=DateTimeFormatter.ofPattern("d-m-y");
		String dateString=zdt.format(df);
		System.out.println(dateString);
		*/
		ZoneId zid=ZoneId.of("America/Los_Angeles");
		LocalDateTime ldt=LocalDateTime.of(2021, 3,11,2,30);
		ZonedDateTime zdt=ZonedDateTime.of(ldt, zid);
		zdt=zdt.withEarlierOffsetAtOverlap();
		System.out.println(zdt.getHour());
		
	}

}
