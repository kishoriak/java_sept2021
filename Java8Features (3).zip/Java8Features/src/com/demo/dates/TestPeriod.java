package com.demo.dates;

import java.time.LocalDate;
import java.time.Period;

public class TestPeriod {

	public static void main(String[] args) {
		LocalDate dt=LocalDate.now();
		LocalDate doj=LocalDate.of(1994, 2, 3);
		Period p=Period.between(dt, doj);
		
		System.out.println("experience: " +p.getYears());

		// How many days are remaining to complete 50 years
		LocalDate bdate=LocalDate.of(2000, 04, 27);
		LocalDate dateat50=LocalDate.of(2000+50,04, 27);
		Period p1=Period.between(dt,dateat50);
		System.out.println("no of days remianing" +p1.getYears()+"years"+p1.getMonths()+"months"+p1.getDays()+"Days");
	}

}
