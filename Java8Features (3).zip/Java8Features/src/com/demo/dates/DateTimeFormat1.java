package com.demo.dates;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class DateTimeFormat1 {

	public static void main(String[] args) {
		//DateTimeFormatter df=DateTimeFormatter.ofPattern("H'h'm'm on' dd MM y");
		DateTimeFormatter df=DateTimeFormatter.ofPattern("'on' dd MM y");
		//LocalDateTime ldt=LocalDateTime.parse("7h30m on 09 05 2021",df);
		//LocalDateTime ldt=LocalDateTime.parse("on 09 05 2021",df);
		LocalDate ld=LocalDate.parse("on 09 05 2021",df);
		System.out.println("localdate "+ld);
		/*ZonedDateTime zdt=ZonedDateTime.of(ldt,ZoneId.of("America/Los_Angeles"));
		DateTimeFormatter stddf=DateTimeFormatter.ISO_ZONED_DATE_TIME;
		DateTimeFormatter formatStyle1=DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG);
		String dt1=zdt.format(stddf);//2021-05-09T8:15:00+01:00[America/Los_Angeles]
		String dt2=zdt.format(formatStyle1); // May 9,2021 8:15:00 AM UTC+01:00
		System.out.println("Zined format"+dt1);
		System.out.println("long format style"+dt2);*/

	}

}
