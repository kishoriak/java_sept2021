package com.demo.dates;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public class DateTimeZoneEx2 {

	public static void main(String[] args) {
		LocalDateTime ldt=LocalDateTime.of(2018, 02,20,15,0); //ldt2018-02-20T15:00
		LocalDate ld=LocalDate.of(2018, 02,20); //ld  2018-02-20
		LocalTime lt=LocalTime.of(10,0); //lt  10:00
		//writing 0 before 3 is compulsory otherwise it throws runtime exception Invalid id
		//ZoneOffset ofs1=ZoneOffset.of("+3:00");  
		ZoneOffset ofs1=ZoneOffset.of("+03:00"); //ofs1  +03:00
		ZoneOffset ofs2=ZoneOffset.of("+01:00"); //ofs2 +01:00
		OffsetDateTime zdt1=OffsetDateTime.of(ldt, ofs1);  //offsetdatetime1  2018-02-20T15:00+03:00
		OffsetDateTime zdt2=OffsetDateTime.of(ld,lt, ofs2);  //offsetdatetime  2018-02-20T10:00+01:00
		boolean isBefore=zdt1.minusHours(4).isBefore(zdt2);//true
		System.out.println("ldt" +ldt);
		System.out.println("ld" +ld);
		System.out.println("lt" +lt);
		System.out.println("ofs1" +ofs1);
		System.out.println("ofs1" +ofs2);
		System.out.println("offsetdatetime1" +zdt1);
		System.out.println("offsetdatetime2" +zdt2);
		System.out.println("isBefore" +isBefore);

	}

}
