package com.demo.dates;

import java.time.Instant;
import java.time.temporal.ChronoField;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;

public class InstantClassDemo {

	public static void main(String[] args) {
		
		        Instant i = Instant.now();
		        System.out.println(i);

		        Instant i2 = i.with(ChronoField.INSTANT_SECONDS,1);
		        System.out.println(i2);
		    }

		    private static final TemporalAdjuster sameInstantOfLastDay = new TemporalAdjuster() {
		        @Override
		        public Temporal adjustInto(Temporal temporal) {
		            if (temporal.isSupported(ChronoField.INSTANT_SECONDS)) {
		                long i = temporal.getLong(ChronoField.INSTANT_SECONDS);
		                return Instant.ofEpochSecond(i - (60 * 60 * 24));
		            }
		            return null;
		        }
		    };
		

	}

