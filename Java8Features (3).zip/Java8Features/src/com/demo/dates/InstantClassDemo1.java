package com.demo.dates;
import java.time.*;
import java.time.temporal.*;
public class InstantClassDemo1 {

	public static void main(String[] args) {
		       // create a Instant object
		        Instant local= Instant.parse("2021-05-13T19:55:30Z");
		                
		  
		        // print instance
		        System.out.println("Instant before"
		                           + " applying method: "
		                           + local);
		  
		        // apply with method of Instant class
		       Instant updatedlocal= local.with(ChronoField.INSTANT_SECONDS,45000000000L);
		        
		        
		      //generate unsupportedTemporal exception , use only with seconds
		       // Instant updatedlocal= local.with(ChronoField.YEAR,5);
		        
		        
		      //generate unsupportedTemporal exception , use only with seconds
		       // Instant updatedlocal= local.with(ChronoField.MONTH_OF_YEAR,10); 
		        
		        //generate start time on time line
		        //Instant updatedlocal= local.with(Instant.EPOCH);  /// 1970-01-01T00:00:00Z
		        // print instance
		        System.out.println("Instant after applying method: "+ updatedlocal);
		   

	}

}
