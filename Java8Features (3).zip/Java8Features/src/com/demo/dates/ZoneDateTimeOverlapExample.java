package com.demo.dates;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ZoneDateTimeOverlapExample {

	public static void main(String[] args) {
		ZoneId zid=ZoneId.of("Europe/Paris");
		//daylight started in paris at this date and time
		LocalDateTime lForwardDST=LocalDateTime.of(2018, 3,25,2,30);  
		
		// daylight stops at this date and time
		LocalDateTime lBackwordDST=LocalDateTime.of(2018, 10,28,2,30);  
		
		//because of daylight start the time shows 3:30
		ZonedDateTime zfwDST =ZonedDateTime.of(lForwardDST,zid);
		System.out.println("ZFWDST "+zfwDST); // 2018-03-25T03:30+02:00[Europ/paris] 
		
		 // see the differnce of 1 hr in 2:30 and 3:30
		ZonedDateTime zbkDST =ZonedDateTime.of(lBackwordDST,zid);
		System.out.println("ZFWDST "+zfwDST); // 2018-10-28T02:30+02:00[Europ/paris] 
		
		//to manage this overlap time you may use these functions
		ZonedDateTime zbkEarlier =zbkDST.withEarlierOffsetAtOverlap();   
		ZonedDateTime zbkLater =zbkDST.withLaterOffsetAtOverlap();
		System.out.println("ZFWDSTbkEarlier "+zbkEarlier);
		System.out.println("ZFWDSTbkEarlierLater "+zbkLater);
		
		ZonedDateTime zfwEarlier =zfwDST.withEarlierOffsetAtOverlap();   
		ZonedDateTime zfwLater =zfwDST.withLaterOffsetAtOverlap();
		System.out.println("ZFWDSTbkEarlier "+zfwEarlier);
		System.out.println("ZFWDSTbkEarlierLater "+zfwLater);
	}

}
