package com.demo.dates;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Set;

public class TestWithXXMethods {

	public static void main(String[] args) {
		LocalTime lt=LocalTime.of(0, 1,2);
		//Returns a copy of this LocalTime with the hour-of-day altered,minutes and seconds also altered
		//original object will remain unchanged. 
		
		System.out.println("Changed LoacTime"+lt.withHour(3).withMinute(4).withSecond(5)); 
		
		LocalDate dt=LocalDate.of(2021,4,3);
		//DateTimeFormatter fmt=DateTimeFormatter.ofPattern("yyyy mm dd"); //this throws exception because time is not part of LocaDate
		DateTimeFormatter fmt=DateTimeFormatter.ofPattern("yyyy MM dd");
		String formatDate=dt.format(fmt);
		System.out.println("Formated date"+formatDate);
		Clock c=Clock.system(ZoneId.of("America/Los_Angeles"));
		LocalDateTime ldt1=LocalDateTime.now(c);
		System.out.println("Time and date"+ldt1);
		
		Set<String> szone=ZoneId.getAvailableZoneIds();
		szone.stream().forEach(System.out::println);
		
 
	}

}
