package com.demo.dates;

import java.time.LocalTime;
import java.time.OffsetTime;
import java.time.ZoneOffset;

public class ZoneDateTimeDemo {

	public static void main(String[] args) {
		LocalTime lt=LocalTime.of(10,20);
		ZoneOffset offset=ZoneOffset.of("+06:00");
		
		//new offset object is create with combination of LocalDate lt and offset
		OffsetTime ot1=OffsetTime.of(lt,offset); // 10:20+06:00
		System.out.println("now offset"+OffsetTime.now());
		// a new offset is craeted by copying ot1 with some changes in hrs and minutes
		OffsetTime ot2=ot1.plusHours(3).minusMinutes(10); //13:10+06:00
		ZoneOffset ot3=ZoneOffset.of("+09:00");   /// new Zone offset is created
		
		
		//since difference between ot1 and ot3 offset is 3 
		//so it will add 3 in ot2 : 13:10+06:00 time hence 
		//the o/p ot4:  16:10+09:00 
		OffsetTime ot4=ot2.withOffsetSameInstant(ot3);  // new time by adding offset
		
		 
		//retrieves hr from ot4
		int hr=ot4.getHour();
		System.out.println("Offset: " +offset);
		System.out.println("ot1 : "+ot1);
		System.out.println("ot2 : "+ot2);
		System.out.println("ot3 : "+ot3);
		System.out.println("ot4 : "+ot4);
		
		System.out.println("hr: "+ot4.getHour()); // 16
		System.out.println("hr ot1: "+ot1.getHour()); 
	}

}
