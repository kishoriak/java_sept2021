package com.demo.dates;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeFormatter11 {
	public static void main(String[] args) {
		ZonedDateTime zdt=ZonedDateTime.parse("2021-06-30T12:20:30+02:00");
		DateTimeFormatter df=DateTimeFormatter.ofPattern("d-M-y");
		String dateString=zdt.format(df);
		System.out.println(dateString);

	}

}
