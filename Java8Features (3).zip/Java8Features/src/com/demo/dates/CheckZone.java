package com.demo.dates;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class CheckZone {
	public static void main(String[] args) {
		ZoneId z=ZoneId.systemDefault();
		System.out.println(z);
		ZonedDateTime zdt=ZonedDateTime.now();
		System.out.println(zdt);
		ZoneId z1=ZoneId.of("America/Los_Angeles");
		ZonedDateTime zdtAmerica=ZonedDateTime.now(z1);
		System.out.println(zdtAmerica);
	}

}
