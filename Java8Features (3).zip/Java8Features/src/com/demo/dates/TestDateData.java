package com.demo.dates;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class TestDateData {

	public static void main(String[] args) {
		//Date d=new Date();
		LocalDate ldt=LocalDate.now();
		LocalDate ldt1=LocalDate.of(2012,11,22);
        LocalDate ldt2=LocalDate.parse("2013-11-22"); 		
        LocalDate ldt3=LocalDate.parse("2013-11-22",DateTimeFormatter.ISO_DATE);
	}

}
