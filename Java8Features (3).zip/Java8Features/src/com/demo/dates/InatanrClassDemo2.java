package com.demo.dates;

import java.time.Instant;

public class InatanrClassDemo2 {

	public static void main(String[] args) {
		Instant now = Instant.now();
		//now.getNano();
		
	    //Gets the number of seconds from the Java epoch of 1970-01-01T00:00:00Z. 
		System.out.println("Epoch second"+now.getEpochSecond()); 
		
		//Gets the number of nanoseconds, later along the time-line, from the start of the second
		//The nanosecond-of-second value measures the total number of nanoseconds from
	    // the second returned by  getEpochSecond.
		System.out.println("Nano second"+now.getNano());
		
	} 

}
