package com.demo.dates;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DaylightSvingExample1 {
	public static void main(String[] args) {
		Period p=Period.ofDays(1);
		Duration d=Duration.ofDays(1);
		ZoneId z=ZoneId.of("America/New_York");  //day light saving starts at early morning
		LocalDateTime ldt=LocalDateTime.of(2018, 3,10,12,0);
		ZonedDateTime zdt=ZonedDateTime.of(ldt, z);
		System.out.println("zdt"+zdt );
		ZonedDateTime periodzdt=zdt.plus(p); //018-03-10T12:00-5:00[America/New_York]
		ZonedDateTime durationzdt=zdt.plus(d);
		
		//this will add 24 hrs in the given date but offset it changing to 4 (1 hr less) because of daylight saving started
		System.out.println("Period Zdt"+periodzdt); // 2018-03-11T12:00-4:00[America/New_York]
		
		//this is adding 24 hrs in the given date but also considering Daylight saving starts
		//it also increases time by 1 hr.to the local time
		System.out.println("Duration zdt: "+durationzdt); //2018-03-11T13:00-04:00[America/New_York]
	}

}
