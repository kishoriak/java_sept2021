package com.demo.dates;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateTimeFormating {

	public static void main(String[] args) {
		LocalDate ld=LocalDate.now();
		System.out.println("leap year:"+ld.isLeapYear());
		//LocalDate dt=LocalDate.parse("2011-03-02");
		//runtime exception because we are trying to convert LocalDate into DateTime format time information is missing
		//String s1=ld.format(DateTimeFormatter.ISO_DATE_TIME);
		String s1=ld.format(DateTimeFormatter.ISO_DATE);
		//this will work
		//String s1=ld.format(DateTimeFormatter.ISO_DATE); 
		System.out.println(s1);
		
		LocalDate dt1=LocalDate.parse("2011-03-02");
		LocalDate dt2=dt1.plusDays(5).plusMonths(3);
		System.out.println("dt2"+dt2);
		System.out.println("dt1"+dt1);
	}

}
