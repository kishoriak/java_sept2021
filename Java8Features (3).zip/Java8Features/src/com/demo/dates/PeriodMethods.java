package com.demo.dates;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalTime;
import java.time.Period;
import java.time.temporal.ChronoField;

public class PeriodMethods {

	public static void main(String[] args) {
		
		  
		        // Get the String to be parsed
		        //String period = "P1Y2M21D";
		         String period = "p02y";  // the string is incase sensitive
		        // Parse the String into Period
		        // using parse() method
		      /*  Period p = Period.parse(period);
		  
		        System.out.println(p.getYears() + " Years\n"
		                           + p.getMonths() + " Months\n"
		                           + p.getDays() + " Days");
		        
		        
		        Instant ins1=Instant.parse("2020-02-02T00:00:00z");//line1"
		        Instant ins2=ins1.with(ChronoField.SECOND_OF_MINUTE,30);//line2"
		        
		        System.out.println(ins2);*/
		         Duration d1=Duration.parse("p2DT30H45M");
		         LocalTime t1=LocalTime.of(12,30).plus(d1);
		         System.out.println(t1);


		    
	}

}
