package com.demo.dates;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class TemporalQuestion2 {

	public static void main(String[] args) {
		LocalTime lt1=LocalTime.of(15,0);
		LocalTime lt2=ChronoUnit.MINUTES.addTo(lt1, 50);
		long span=ChronoUnit.HOURS.between(lt1, lt2);
		System.out.println(span);

	}

}
