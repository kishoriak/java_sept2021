package com.demo.binaryinterfaces;

import java.util.function.BiPredicate;

public class TestBiPredicate {
	public static void main(String[] args) {
		BiPredicate<Integer,Double> bp=(i,d)->i>d;
		boolean ans=bp.test(0, 1.0);
		if(ans)
			System.out.println("int is greater");
		else
			System.out.println("double is greater");
	}

}
