package com.demo.binaryinterfaces;

import java.util.function.UnaryOperator;

import com.demo.functionalinterfaces.test.Person;

public class TestUnaryOperator {

	public static void main(String[] args) {
		UnaryOperator<Person> uo=p->new Person(p.getName().toUpperCase(),p.getAge()+2,p.getGender());
		Person p1=new Person("Rajan",20,Person.Gender.MALE);
		Person p2=uo.apply(p1);
		System.out.println(p2.getName()+"   "+p2.getAge());  //RAJAN  22
		
		UnaryOperator<Double> op=d->d+2.0;
		double result=op.apply(1.0);
		System.out.println(result);


	}

}
