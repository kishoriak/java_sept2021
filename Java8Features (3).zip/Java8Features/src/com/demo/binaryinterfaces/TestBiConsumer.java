package com.demo.binaryinterfaces;

import java.util.function.BiConsumer;
import java.util.function.ObjIntConsumer;

public class TestBiConsumer {

	public static void main(String[] args) {
		BiConsumer<String,String> bc=(s1,s2)->System.out.println(s1+" "+s2);
		bc.accept("Hello", "Everybody");
		ObjIntConsumer<String> ic=(s,i)->System.out.println(s.length()-i);
		ic.accept("Welcome", 2); // will print 5(7-2) 
				

	}

}
