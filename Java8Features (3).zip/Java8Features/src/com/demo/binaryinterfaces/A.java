package com.demo.binaryinterfaces;

public class A {
	private String data;
	private int a;
	public A(String data, int a) {
		super();
		this.data = data;
		this.a = a;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	
	

}
