package com.demo.binaryinterfaces;

import java.util.function.BiFunction;
import java.util.function.ToDoubleBiFunction;

public class TestBiFunction {
	public static void main(String[] args) {
		A a=new A("test",10);
		B b=new B("Welcome",20);
		BiFunction<A,B,String> bf=(x,y)->x.getData()+","+b.getData();
		ToDoubleBiFunction<A,B> dbf=(x,y)->x.getA()+b.getA();
		System.out.println("data : "+bf.apply(a, b));
		System.out.println("a : "+dbf.applyAsDouble(a, b));
		
		
	}

}
