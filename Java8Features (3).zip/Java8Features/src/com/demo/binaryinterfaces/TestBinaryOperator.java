package com.demo.binaryinterfaces;

import java.util.function.BinaryOperator;
import java.util.function.LongBinaryOperator;

public class TestBinaryOperator {

	public static void main(String[] args) {
		BinaryOperator<String> bo=(s1,s2)->s1.concat(s2);
		String s=bo.apply("app","le");
		System.out.println(s); //apple
		LongBinaryOperator lbo=(l1,l2)->l1+l2;
		long res=lbo.applyAsLong(23L,12L);
		System.out.println(res); //45

	}

}
