package com.demo.model;

public class ProductFinder {
	public int finder(Product p1,Product p2) {
		return p1.getName().compareTo(p2.getName());
	}
	/*
	 * public int finder(Product p1,Product p2,Product p3) { return
	 * p1.getName().compareTo(p2.getName()); }
	 */
}
