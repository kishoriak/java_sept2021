package com.demo.model;

import java.util.Random;

public class MyModel {
	private int id;
	private static Random gen;
	static {
		gen=new Random();
	}

	public MyModel() {
		System.out.println("Mymodel default constructor called");
		id=gen.nextInt();  // will generate random number
	}

	
	public MyModel(int id) {
		System.out.println("Mymodel parametrised constructor called");
		this.id = id;
	}


	public int getId() {
		return id;
	}

	

}
