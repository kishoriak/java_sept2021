package com.demo.test1;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public class TestMyClass {
	public static void main(String[] args) {
		MyClass ob=new MyClass(12);
		MyClass ob1=new MyClass<>(12);
		MyClass ob2=new MyClass<Integer>(12);
		MyClass<Number> ob4=new MyClass<>(23);
		MyClass<Long> ob7=new MyClass<>(34l);
		//MyClass<> ob2=new MyClass<Integer>();
		//MyClass<Integer> ob5=new MyClass<>();
		List<Number> l=new ArrayList<>(); 
	}

}
