package com.demo.test1;

public class MyClass<T extends Number>{
	private T id;
	   public MyClass(T id){
	            this.id=id;
	    }
	             /*code*/
	}
