
public class TestStudent {

	public static void main(String[] args) {
		Student s=new Student();
		s.setSid(12);
		
		
	}

}
