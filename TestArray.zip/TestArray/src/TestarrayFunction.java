
public class TestarrayFunction {
	public static void main(String[] args) {
		
	
		int[][] myarr=ArrayUtility.acceptData();
		//ArrayUtility.findMin();
		//ArrayUtility.findMax();
	}

}
