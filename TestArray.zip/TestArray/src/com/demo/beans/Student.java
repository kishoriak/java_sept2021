package com.demo.beans;

public class Student {
	private int id;
	private String name;
	Gender gender;
	public enum Gender{
		male,female;
	}
	public Student(int id, String name, Gender gender) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", gender=" + gender + "]";
	}
	

}
