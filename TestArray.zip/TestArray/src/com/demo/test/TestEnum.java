package com.demo.test;

import java.util.Scanner;

import com.demo.beans.Student;
import com.demo.beans.Student.Gender;
import com.demo.enums.Cofee;

public class TestEnum {

	public static void main(String[] args) {
		Cofee c=Cofee.small;
		
		
		switch(c) {
		case small:
			System.out.println("small selected");
			System.out.println(c.getPrice()+"----->"+c.getSize());
			break;
		case medium:
			System.out.println("medium selected");
			break;
		case big:
			System.out.println("big selected");
		}
		System.out.println();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size");
		String s1=sc.next();
		Cofee c1=Cofee.valueOf(s1);
		System.out.println(c1.getPrice());
		Student s=new Student(12,"Kishori",Gender.male);
	}
	
	

}
