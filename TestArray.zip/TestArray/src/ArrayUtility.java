import java.util.Scanner;

public class ArrayUtility {
   public static int[][] acceptData() {
	   int[][] arr=new int[5][5];
	   Scanner sc=new Scanner(System.in);
	   
	   System.out.println("enter the numbers");
	   for(int i=0;i<arr.length;i++) {
		   for(int j=0;j<arr[i].length;j++) {
			   arr[i][j]=sc.nextInt();
		   }
	   }
	   return arr;
   }
}
