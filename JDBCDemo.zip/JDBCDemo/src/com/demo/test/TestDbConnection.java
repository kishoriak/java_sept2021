package com.demo.test;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

public class TestDbConnection {

	public static void main(String[] args) {
		//Step 1:
		String url="jdbc:mysql://localhost:3306/hsbcdb?useSSL=false";
		String username="root";
		String password="root123";
		Connection conn=null;
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			 conn=DriverManager.getConnection(url,username,password);
			//conn.setAutoCommit(false);
			if(conn!=null) {
				System.out.println("connection done");
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery("select * from producthsbc");
			    while(rs.next()){
				    System.out.println("id : "+rs.getInt(1));
				    System.out.println("Name : "+rs.getString(2));
				    System.out.println("Manufactury date :"+rs.getDate(6));
				}
			    rs=st.executeQuery("select * from category");
			    while(rs.next()){
				    System.out.println("id : "+rs.getInt(1));
				    System.out.println("Name : "+rs.getString(2));
				    System.out.println("Description :"+rs.getString(3));
				}
			    
			    
			    ////using prepared statement
			    PreparedStatement ps=conn.prepareStatement("select * from producthsbc where cid=?");
			    ps.setInt(1,1);
			    System.out.println("---------------------------------------------");
			    ResultSet rs1=ps.executeQuery();
			    while(rs1.next()){
				    System.out.println("id : "+rs1.getInt(1));
				    System.out.println("Name : "+rs1.getString(2));
				    System.out.println("Manufactury date :"+rs1.getDate(6));
				}
			    Scanner sc=new Scanner(System.in);
			    System.out.println("enetr CID");
			    int cid=sc.nextInt();
			    CallableStatement cst=conn.prepareCall("{call getcnt(?,?)}");
			    cst.setInt(1, cid);
			    cst.registerOutParameter(2,Types.INTEGER);
			    boolean status=cst.execute();
			    int data= cst.getInt(2);
			    System.out.println("Count : "+data);
			    //conn.commit();
			}
			else {
				System.out.println("connection not done");
			}
		} catch (SQLException e) {
			System.out.println("connection not done");
			/*try {
				//conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
			e.printStackTrace();
		}
	}

}
