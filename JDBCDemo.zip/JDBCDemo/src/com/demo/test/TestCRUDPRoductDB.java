package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

public class TestCRUDPRoductDB {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ProductService pservice=new ProductServiceImpl();
		int choice=0;
		do {
			System.out.println("1. Add product\n2.display all\n3. display by id\n4.dispaly by price\n");
			System.out.println("5. update product\n6. delete product\n7.exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				pservice.addProduct();
				break;
			case 2:
				pservice.getAll();
				break;
			case 3:
				System.out.println("enetr id");
				int id=sc.nextInt();
				Product p=pservice.getById(id);
				if(p!=null) {
					System.out.println(p);
				}
				else {
					System.out.println("not found");
				}
				break;
			case 4:
				System.out.println("enetr low price");
				int lpr=sc.nextInt();
				System.out.println("enetr high price");
				int hpr=sc.nextInt();
				List<Product> plist=pservice.getByPrice(lpr,hpr);
				if(plist!=null)
				     plist.stream().forEach(System.out::println);
				else
					System.out.println("not found");
				break;
			case 5:
				System.out.println("enetr id");
				id=sc.nextInt();
				System.out.println("enetr new qty");
				int qty=sc.nextInt();
				System.out.println("enetr new price");
				double pr=sc.nextDouble();
				boolean status=pservice.updateById(id,qty,pr);
				if(status) {
					System.out.println("updation done");
				}
				else {
					System.out.println("not found");
				}
				break;
			case 6:
				System.out.println("enetr id");
				id=sc.nextInt();
				status=pservice.deleteById(id);
				if(status) {
					System.out.println("deleteion done");
				}
				else {
					System.out.println("not found");
				}
				break;
			case 7:
				pservice.closeConnection();
				sc.close();
				System.out.println("Thank you for visiting.....");
				break;
			}
		}while(choice!=7);
		
	}

}
