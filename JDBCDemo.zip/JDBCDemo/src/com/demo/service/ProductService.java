package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	void addProduct();

	void getAll();

	void closeConnection();

	Product getById(int id);

	List<Product> getByPrice(int lpr, int hpr);

	boolean updateById(int id, int qty, double pr);

	boolean deleteById(int id);

}
