package com.demo.dao;

public class MyFactory {
	public static ProductDao getProductDao() {
		return new ProductDaoImpl();
	}

}
