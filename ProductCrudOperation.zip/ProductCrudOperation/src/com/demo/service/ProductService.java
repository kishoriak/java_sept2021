package com.demo.service;

import java.util.List;

import com.demo.beans.Category;
import com.demo.beans.Product;

public interface ProductService {

	List<Category> getAllCategory();

	List<Product> getAllProducts();

	void addProduct(Product p);

	Product getById(int pid);

	void updateProduct(Product p);

	void deleteById(int pid);

	//String getProductsByCategory(int cid);

}
