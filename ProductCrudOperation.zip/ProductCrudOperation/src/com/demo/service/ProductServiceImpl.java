package com.demo.service;

import java.util.List;

import com.demo.beans.Category;
import com.demo.beans.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;
//import com.google.gson.Gson;


public class ProductServiceImpl implements ProductService{
	ProductDao pdao;

	public ProductServiceImpl() {
		super();
		this.pdao = new ProductDaoImpl();
	}

	  
	@Override
	public List<Category> getAllCategory() {
		return pdao.findCategory();
	}


	@Override
	public List<Product> getAllProducts() {
		return pdao.findAllProducts();
	}


	@Override
	public void addProduct(Product p) {
		pdao.save(p);
		
	}


	@Override
	public Product getById(int pid) {
		return pdao.findById(pid);
	}


	@Override
	public void updateProduct(Product p) {
		pdao.updateProduct(p);
		
	}


	@Override
	public void deleteById(int pid) {
		pdao.deleteById(pid);
		
	}


	/*
	 * @Override public String getProductsByCategory(int cid) { List<Product>
	 * plist=pdao.findProductsByCategory(cid); Gson gson=new Gson(); String
	 * jsonprodlist=gson.toJson(plist); System.out.println(jsonprodlist); return
	 * jsonprodlist;
	 * 
	 * }
	 */
	

}
