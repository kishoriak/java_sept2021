package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Category;
import com.demo.beans.Product;

public class ProductDaoImpl implements ProductDao{
    static Connection con;
    static PreparedStatement pselcat,pprodByCat,pgetAllProd,inspr,pgetById,pupById,pdelById;
    static {
    	con=DBUtil.getMyConnection();
    	try {
			pselcat=con.prepareStatement("select * from category");
			pgetAllProd=con.prepareStatement("select * from producthsbc");
			pupById=con.prepareStatement("update producthsbc set qty=?,price=? where pid=?");
			pgetById=con.prepareStatement("select * from producthsbc where pid=?");
			inspr=con.prepareStatement("insert into producthsbc values(?,?,?,?,?,?,?)");
			pprodByCat=con.prepareStatement("select * from producthsbc where cid=?");
			pdelById=con.prepareStatement("delete from  producthsbc where pid=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	@Override
	public List<Category> findCategory() {
		List<Category> clist=new ArrayList<>();
		try {
			ResultSet rs=pselcat.executeQuery();
			while(rs.next()) {
				Category c=new Category(rs.getInt(1),rs.getString(2),rs.getString(3));
				clist.add(c);
				
			}
			return clist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public List<Product> findProductsByCategory(int cid) {
		
		try {
			pprodByCat.setInt(1, cid);
			ResultSet rs=pprodByCat.executeQuery();
			List<Product> plist=new ArrayList<>();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getString(5),rs.getDate(6),rs.getInt(7)));
			}
			return plist;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Product> findAllProducts() {
		try {
			List<Product> plist=new ArrayList<>();
			ResultSet rs=pgetAllProd.executeQuery();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getString(5),rs.getDate(6),rs.getInt(7)));
			
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void save(Product p) {
		try {
			inspr.setInt(1,p.getPid());
			inspr.setString(2,p.getPname());
			inspr.setInt(3,p.getQty());
			inspr.setDouble(4,p.getPrice());
			inspr.setString(5,p.getType());
			java.sql.Date sdat=new java.sql.Date(p.getMfg().getTime());
			inspr.setDate(6, sdat);
			inspr.setInt(7,p.getCid());
			int num=inspr.executeUpdate();
			if (num>0) {
				con.commit();
			}
			
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			//e.printStackTrace();
		}
		
	}

	
	@Override
	public Product findById(int pid) {
		try {
			pgetById.setInt(1, pid);
			ResultSet rs=pgetById.executeQuery();
			if(rs.next()) {
				return new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getString(5),rs.getDate(6),rs.getInt(7));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean updateProduct(Product p) {
		try {
			pupById.setInt(1, p.getQty());
			pupById.setDouble(2,p.getPrice());
			pupById.setInt(3, p.getPid());
			int num=pupById.executeUpdate();
			if(num>0) {
				con.commit();
				return true;
			}
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		return false;
		
	}

	@Override
	public void deleteById(int pid) {
		try {
			pdelById.setInt(1, pid);
			int num=pdelById.executeUpdate();
			if(num>0) {
				con.commit();
				//return true;
			}
			
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				//throw new ProductNotFoundException("not found");
				//e1.printStackTrace();
			}
			e.printStackTrace();
		}
		//return false;
		
	}
   
	   
}
