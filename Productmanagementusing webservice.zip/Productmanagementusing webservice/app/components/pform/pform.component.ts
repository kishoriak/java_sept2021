import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pform',
  templateUrl: './pform.component.html',
  styleUrls: ['./pform.component.css']
})
export class PformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
