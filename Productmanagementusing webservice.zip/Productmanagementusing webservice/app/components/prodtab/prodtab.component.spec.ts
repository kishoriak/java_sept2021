import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProdtabComponent } from './prodtab.component';

describe('ProdtabComponent', () => {
  let component: ProdtabComponent;
  let fixture: ComponentFixture<ProdtabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProdtabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProdtabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
