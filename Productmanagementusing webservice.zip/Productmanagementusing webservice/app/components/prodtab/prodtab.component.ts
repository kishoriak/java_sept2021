import { Component,Input, Output,EventEmitter } from "@angular/core";
import { ProductService } from "src/app/product.service";
import {Product} from '../../Product';

@Component(
    {
        selector:'ptab',
        templateUrl:'./prodtab.component.html',
        styleUrls:['./prodtab.component.css']

    }
)
export class ProdtabComponent{
  prodarr:Product[];
   constructor(private pservice:ProductService){

   }
  ngOnInit(){
     this.pservice.getProducts().subscribe(response=>{this.prodarr=response;});
      console.log(this.prodarr);
  }
  
}
