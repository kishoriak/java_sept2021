import { Injectable } from "@angular/core";
import { Product } from "./Product";
import {HttpClient} from "@angular/common/http";
import {Observable} from 'rxjs';

@Injectable()
export class ProductService{

    constructor(private httpClient:HttpClient){}
    baseurl="http://localhost:8181/product/"
    /*prodarr=[new Product(1,"chiar",23,4000,new Date(2021,9,1)),
    new Product(2,"Table",23,3000,new Date(2000,9,11)),
    new Product(3,"shelf",23,3452,new Date(2000,9,1)),
    new Product(4,"shoerack",23,3451,new Date(2000,9,1))];*/

    


    getProducts():Observable<Product[]>{
        return this.httpClient.get<Product[]>(this.baseurl+"products");
    }
}