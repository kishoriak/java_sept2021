# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 11:35:26 2021

@author: anilk
"""

# f=open(r"test.txt")
# lst=f.readlines()
# print(lst)
# f.close()
with open("test.txt") as f:
    with open("textcopy.txt","w") as f1:
        for line in f:
            line1=line.rstrip('\n')
            str1 = line.split("|")
            if str1[5] == "HR":
                print(str1[1])

            

f=open(r"test.txt")
lst=f.readlines()
print(lst)
f=open(r"test1.txt")
lst1=f.readlines() 
print(lst1)
set1=set()
for s in lst:
    set1.add(s.split("|")[0])

set2=set()
for s in lst1:
    set2.add(s.split("|")[0])
print(set1&set2)


#write a program to list only employees from HR department




       

