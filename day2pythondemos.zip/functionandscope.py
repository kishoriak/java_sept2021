# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 09:45:12 2021

@author: anilk
"""

def function1(a,b):
    a=a+10
    b=b+20
    return a,b

def function2():
    #global cnt
    cnt=23
    cnt=cnt+1
    print("in function2",cnt)
    def f3():
        nonlocal cnt
        cnt=30
        print("in function 3",cnt)
    f3()
    print("after f3",cnt)
        


cnt=0
b=20    
x,y=function1(cnt,b)
print(x,y)

function2()
print("in main",cnt)
