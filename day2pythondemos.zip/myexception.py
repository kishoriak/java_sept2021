# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 15:53:32 2021

@author: anilk
"""

class MyException(Exception):
    def __init__(self,msg="error occured"):
        self.__msg=msg
    def __str__(self):
        return self.__msg