# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 10:35:43 2021

@author: anilk
"""

lst=[12,13,14]
lst2=[]
for num in lst:
    if num%2==0:
        lst2.append(num*num)
    
lst3=[num*num for num in lst if num%2==0]
#lst2.extend(lst3)

lst4=list(filter(lambda x:x%2==0,lst))
lst5=list(map(lambda x:x*x,lst4))

lst33=["one","two","three"]
from functools import reduce
s=reduce(lambda x,y:x+y,lst33)
s1=reduce(lambda x,y:y if len(x) > len(y)  else x,lst33)