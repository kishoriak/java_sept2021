# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 15:32:38 2021

@author: anilk
"""
from myexception import MyException

#import myexception    
try:
    num=int(input("enetr num"))
    num1=int(input("enter second num"))
    if num1<10:
        raise MyException("num2 should be > 10")
    ans=num/num1 
except ValueError as e:
    print(e)
except ZeroDivisionError as e:
    print(e)
except MyException as e:
    print(e)
else:
    print("in else")
finally:
    print("in finally block")
    
    