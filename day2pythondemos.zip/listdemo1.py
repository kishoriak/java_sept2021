# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 09:34:50 2021

@author: anilk
"""
import copy
lst=[12,13,14,[10,20,30]]
lst1=lst
lst.append(45)
print(lst,lst1)
lst2=lst.copy()
lst.append(45)
print(lst,lst1,lst2)
lst[3].append(40)
print(lst,lst1,lst2)
lst4=copy.deepcopy(lst);
lst5=copy.copy(lst)