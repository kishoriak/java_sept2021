# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 17:02:41 2021

@author: anilk
"""

from datetime import datetime


my_string = '2019-10-31'

# Create date object in given time format yyyy-mm-dd
my_date = datetime.strptime(my_string, "%Y-%m-%d")

print(my_date)
print('Type: ',type(my_date))
print('Month: ', my_date.month) # To Get month from date
print('Year: ', my_date.year) # To Get month from year

my_date = datetime.strptime(my_string, "%Y-%m-%d")


print(my_date)
print('Type: ',type(my_date))
print('Month: ', my_date.month) # To Get month from date
print('Year: ', my_date.year) # To Get month from year

fmtdt=my_date.strftime("%y%m%d")
print(fmtdt)

 
s1="hjag ajhdkjhekjdhwkjedh 191030  sfljrljl jrlkjlkrjrfkjr"

if fmtdt in s1:
    print("found")
else:
    print("not found")
    
    
    
    
    

