# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 13:07:20 2021

@author: anilk
"""

import os
from time import time
lst=[("c:\mydata",""),"c:\mylogs","c:\myfiles"]
print(os.getcwd())
for fname in os.listdir():
    #if fname.endswith(".txt"):
    print(fname)
    print(f"time difference {time()-os.path.getctime(fname)}")
    
for (dname,dlist,flist) in os.walk("."):
    print("directory name",dname)
    for fname in flist:
        if fname.endswith("dat"):
            print("****file :" +fname) 
            fn=fname.split(".")[0]+".bak"
            os.rename(os.path.join(dname,fname),os.path.join(dname,fn))
            


import requests
from time import time

start=time()

response=requests.get("https://github.com/kishoriak/java_sept2021")
print(response.content)
print("*"*80)
print(response)
print(f"time of execution: {round(time()-start,2)}")



age=23
#your age is 12 years 
print("your age is ",age,"years")
print(f"your age is {age} years")
