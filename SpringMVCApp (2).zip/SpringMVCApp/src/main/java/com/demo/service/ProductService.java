package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	void addProduct(Product p);

	List<Product> getAllProduct();

	Product getById(int id);

	int updateProduct(Product p);

	void deleteById(int pid);

}
