package com.demo.beans;

public class MyUtility {
	String nm;
	//MyClass ob;
	
	public MyUtility() {
		super();
		this.nm ="Kishori";
	}

	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	 public int factorial(int num) {
		// ob=Mydb.getById(1);
		 try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		synchronized(this) { 
		     nm="Rajan";
		 }
		int fact=1;
		for(int i=2;i<=num;i++) {
			fact=fact*i;
		}
		return fact;
	}
	
	synchronized public void printTable(int num) {
		nm="Revati";
		for(int i=1;i<10;i++) {
			System.out.println(num+"*"+i+"="+(num*i));
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
