package com.demo.beans;

public class Storage {
	private int num;
	private boolean valueSet;
	private boolean endJob;
	
	public Storage() {
		super();
		num=-2;
		valueSet=false;
		endJob=false;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public boolean isValueSet() {
		return valueSet;
	}

	public void setValueSet(boolean valueSet) {
		this.valueSet = valueSet;
	}

	public boolean isEndJob() {
		return endJob;
	}

	public void setEndJob(boolean endJob) {
		this.endJob = endJob;
	}

	synchronized public void get() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if((!valueSet) && (!endJob)){
			try {
				System.out.println("consumer is in wait");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Got: "+num);
		this.valueSet=false;
		notify();
	}
	
	synchronized public void put(int num) {
		if(valueSet) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Put :"+num);
		this.num=num;
		this.valueSet=true;
		notify();
	}

}
