package com.demo.beans;

import java.util.concurrent.Callable;

public class MyTask1 implements Callable<Integer> {
    private int start,end;
    
    
	public MyTask1(int start, int end) {
		super();
		this.start = start;
		this.end = end;
	}


	@Override
	public Integer call() throws Exception {
		int sum=0;
		for(int i=start;i<=end;i++) {
			sum+=i;
		}
		System.out.println(start+" --- "+end+" ------- "+Thread.currentThread().getId());
		return sum;
	}

}
