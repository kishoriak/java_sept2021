package com.demo.threads;

import java.util.Scanner;

import com.demo.beans.Storage;

public class Producer extends Thread{
	private Storage s;
	
	
	public Producer(Storage s) {
		super();
		this.s = s;
	}


	public void run() {
		Scanner sc=new Scanner(System.in);
		String ans="n";
		do {
			System.out.println("enetr number");
			int n=sc.nextInt();
			s.put(n);
			System.out.println("continue(y/n)");
			ans=sc.next();
		}while(ans.equals("y"));
		s.setEndJob(true);
		System.out.println("end of producer");
	}

}
