package com.demo.threads;

import com.demo.beans.MyUtility;

public class FactorialThread implements Runnable{
	private MyUtility ob;
	
	
	public FactorialThread(MyUtility ob) {
		super();
		this.ob = ob;
	}


	public void run() {
		System.out.println("factorial : "+ob.factorial(5));
		
	}

}
