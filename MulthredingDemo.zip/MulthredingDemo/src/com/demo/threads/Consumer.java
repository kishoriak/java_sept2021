package com.demo.threads;

import com.demo.beans.Storage;

public class Consumer extends Thread{
	
private Storage s;
	
	
	public Consumer(Storage s) {
		super();
		this.s = s;
	}
	
	public void run() {
		while(!s.isEndJob()){			
			s.get();
		}
		System.out.println("end of Consumer");
	}

}
