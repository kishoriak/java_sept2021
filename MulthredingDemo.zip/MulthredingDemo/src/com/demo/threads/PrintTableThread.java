package com.demo.threads;

import com.demo.beans.MyUtility;

public class PrintTableThread extends Thread{
	private MyUtility ob;
	private int num;
	
	public PrintTableThread(MyUtility ob, int num) {
		super();
		this.ob = ob;
		this.num = num;
	}

	public void run() {
		ob.printTable(num);
	}

}
