package com.demo.test;

import com.demo.beans.MyUtility;
import com.demo.threads.FactorialThread;
import com.demo.threads.PrintTableThread;

public class TestMultithtreading {

	public static void main(String[] args) {
		MyUtility ob=new MyUtility();
		MyUtility ob1=new MyUtility();
		MyUtility ob2=new MyUtility();
		///using Runnable interface
		FactorialThread fth=new FactorialThread(ob1);
		Thread th =new Thread(fth);
		th.start();
		int num=7;
		//using Thread
		PrintTableThread pth1=new PrintTableThread(ob1,num);
		pth1.setPriority(Thread.NORM_PRIORITY+5);
		num=3;
		PrintTableThread pth2=new PrintTableThread(ob1,num);
		pth1.start();
		pth2.start();
		System.out.println("in main after thread");
		System.out.println("in main after thread");
		System.out.println("end of main");
		try {
			th.join(300);
			pth1.join();
			pth2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("end of main");
	}

}
