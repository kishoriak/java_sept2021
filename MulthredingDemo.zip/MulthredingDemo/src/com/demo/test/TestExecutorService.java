package com.demo.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.demo.beans.MyTask1;

public class TestExecutorService {

	public static void main(String[] args) {
		List<Future> flist=new ArrayList<>();
		ExecutorService es=Executors.newFixedThreadPool(4);
		for(int i=1;i<=91;i=i+10) {
			Future f=es.submit(new  MyTask1(i,i+9));
			flist.add(f);
		}
		int s=0;
		for(Future f:flist) {
			try {
				s=s+(Integer)f.get();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Final addition : "+s);
		es.shutdown();
		
		

	}

}
