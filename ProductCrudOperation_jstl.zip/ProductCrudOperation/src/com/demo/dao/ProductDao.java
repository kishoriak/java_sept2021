package com.demo.dao;

import java.util.List;

import com.demo.beans.Category;
import com.demo.beans.Product;

public interface ProductDao {

	List<Category> findCategory();

	

	List<Product> findProductsByCategory(int cid);



	List<Product> findAllProducts();



	void save(Product p);



	



	Product findById(int pid);



	boolean updateProduct(Product p);



	void deleteById(int pid);




}
