package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.beans.User;
import com.demo.service.LoginService;
import com.demo.service.LoginServiceImpl;

@WebServlet("/validate")
public class LoginServlet extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		PrintWriter out=response.getWriter();
		request.getPathInfo();
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		LoginService lservice=new LoginServiceImpl();
		User user=lservice.validateUser(uname,pass);
		
		   
		if(user!=null){
			HttpSession  session=request.getSession();
			session.setMaxInactiveInterval(20);
			if(session.isNew()) {
				System.out.print("new session");
			}
			else {
				session.invalidate();
				session=request.getSession(true);  ///forces to create new session
				 
			}
			session.setAttribute("user", user);
			RequestDispatcher rd=request.getRequestDispatcher("displayProduct");
			rd.forward(request, response);
		}
		else {
			out.println("<h1>pls renenter credentials</h1>");
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request, response);
			
			
		}
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		doPost(request,response);
	}

}
