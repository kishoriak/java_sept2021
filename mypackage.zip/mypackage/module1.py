# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 10:12:43 2021

@author: anilk
"""

def addition(x,y):
    x=x+10
    y=y+20
    return x,y

if __name__=="__main__":
    print("prathmesh",addition(23,11))