package com.demo.beans;

public class User {
	private int uid;
	private String uname;
	private String mobile;
	private Address addr1;
	public User() {
		super();
		System.out.println("in user default constructor");
	}
	public User(int uid, String uname, String mobile,Address addr) {
		super();
		System.out.println("in user parametrised constructor");
		this.uid = uid;
		this.uname = uname;
		this.mobile = mobile;
		this.addr1=addr;
	}
	
	public Address getAddress() {
		return addr1;
	}
	public void setAddress(Address address) {
		System.out.println("in user setAddress method");
		this.addr1 = address;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		System.out.println("in user setuid method");
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		System.out.println("in user setuname method");
		this.uname = uname;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		System.out.println("in user setmobile method");
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", mobile=" + mobile + ", address=" + addr1 + "]";
	}
	
	

}
