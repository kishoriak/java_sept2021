package com.demo.beans;

public class Address {
	private int aid;
	private String street,city;
	public Address() {
		super();
		System.out.println("in address default constructor");
	}
	public Address(int aid, String street, String city) {
		super();
		System.out.println("in address parametrised constructor");
		this.aid = aid;
		this.street = street;
		this.city = city;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		System.out.println("in address setuid method");
		this.aid = aid;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		System.out.println("in address setStree method");
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		System.out.println("in address setCity method");
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [aid=" + aid + ", street=" + street + ", city=" + city + "]";
	}
	
	

}
