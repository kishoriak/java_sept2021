package com.demo.service;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.demo.exception.AgeException;
import com.demo.exception.InvalidNegativeAmtException;

public class DateService {

	public static Date acceptBirthDate() throws  AgeException, InvalidNegativeAmtException, ParseException{//,FileNotFoundException,NullPointerException {
		Scanner sc=new Scanner(System.in);
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yy");
		System.out.println("enetr bdate in dd/mm/yy");
		String str=sc.next();
		Date dt=null;
		dt=sdf.parse(str);
		System.out.println("enetr amt");
		int amt=sc.nextInt();  
		if(amt<0) {
			Throwable th=new Throwable("be specific with amt");
			throw new InvalidNegativeAmtException("amount cannto be negative",th);
		}
		System.out.println("enetr age");
		int age=sc.nextInt();
		if((age<18)||(age>60) )
		{
			throw new AgeException("Age should be between 18 and 60");
		}
		return dt;
	}

}
