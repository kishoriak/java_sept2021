package com.demo.exception;

public class AgeException extends Exception{

	public AgeException() {
		super();
	}
	public AgeException(String msg){
		super(msg);
	}
	public AgeException(String message,Throwable cause) {
		super(message,cause);
	}
}
