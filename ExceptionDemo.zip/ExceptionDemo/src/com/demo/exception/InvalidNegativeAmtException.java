package com.demo.exception;



public class InvalidNegativeAmtException extends Exception{

	public InvalidNegativeAmtException(String msg){
		super(msg);
	}
	public InvalidNegativeAmtException(String message,Throwable cause) {
		super(message,cause);
	}
}

