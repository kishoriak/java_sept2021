package com.demo.test;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestException {

	public static int division(int n1,int n2) {
		try {
		    int c=n1/n2;
		    return c;
		}catch(ArithmeticException e) {
			System.out.println("aero division error");
			throw e;
		}
		return 0;
	} 
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<3;i++) {
		try {
			System.out.println("enter number");
			int num1=sc.nextInt(); 
			
			System.out.println("enter number");
			int num2=sc.nextInt(); 
		
			
			System.out.println("The number you entered :"+num1+"----"+num2);
			int div=division(num1,num2);
			System.out.println("The number you entered :"+num1+"----"+num2+" Division : "+div);
			break;
		}catch(InputMismatchException e) {
			System.out.println("pls enter number");
			sc.next();
		}catch(ArithmeticException e) {
			System.out.println("num2 cannot be zero, pls reenter");
		}catch(Exception e) {
			System.out.println("error occured"+"----"+e.getMessage());
		}finally {
			System.out.println("finally");
		}
		
		
		}
		System.out.println("continue with main");
		
		
	}

}
