package com.demo.test;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.Date;

import com.demo.exception.AgeException;
import com.demo.exception.InvalidNegativeAmtException;
import com.demo.service.DateService;

public class TestException1 {
	
	

	public static void main(String[] args)  {
		System.out.println("user will enetr date");
        Date dt;
		try {
			dt = DateService.acceptBirthDate();
			System.out.println(dt);
		} catch (ParseException | AgeException | InvalidNegativeAmtException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getCause().getMessage());
			//e.printStackTrace();
		} catch(Exception e) {
			System.out.println("error occured");
		}
        
	}

}
