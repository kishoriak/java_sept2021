package com.demo.dao;

import com.demo.beans.Student;
import com.demo.exception.StudentNotFoundException;

public interface StudentDao {

	void saveStudent(Student student);

	Student[] getAll();

	void writeToFile();

	void readFromFile();

	Student findById(int id) throws StudentNotFoundException ;

}
