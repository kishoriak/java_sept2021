package com.demo.service;

import java.util.Scanner;
import java.util.stream.Stream;

import com.demo.beans.Student;
import com.demo.dao.StudentDao;
import com.demo.dao.StudentDaoImpl;
import com.demo.exception.StudentNotFoundException;

public  class StudentServiceImpl implements StudentService{
	StudentDao studentDao;
	public StudentServiceImpl() {
		studentDao=new StudentDaoImpl();
	}
	@Override
	public void addStudent() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String nm=sc.next();
		System.out.println("enter m1");
		int m1=sc.nextInt();
		System.out.println("enter m2");
		int m2=sc.nextInt();
		System.out.println("enter m3");
		int m3=sc.nextInt();
		studentDao.saveStudent(new Student(id,nm,m1,m2,m3));
	}
	@Override
	public void displayAll() {
	 Student[] sarr=studentDao.getAll();
	 Stream.of(sarr).forEach(System.out::println);
		
	}
	@Override
	public void writedata() {
		studentDao.writeToFile();
		
	}
	@Override
	public void readData() {
		studentDao.readFromFile();
		
	}
	@Override
	public Student searchById(int id) throws StudentNotFoundException {
		return studentDao.findById(id);
	}

}
