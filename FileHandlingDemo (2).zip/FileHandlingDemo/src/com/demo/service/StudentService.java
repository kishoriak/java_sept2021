package com.demo.service;

import com.demo.beans.Student;
import com.demo.exception.StudentNotFoundException;

public interface StudentService {

	void addStudent();

	void displayAll();

	void writedata();

	void readData();

	Student searchById(int id) throws StudentNotFoundException;

}
