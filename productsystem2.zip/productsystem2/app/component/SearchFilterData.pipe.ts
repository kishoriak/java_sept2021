import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'searchFilter'
})
export class SearchFilterData implements PipeTransform{
    transform(arr: any[], searchText:string) {
        console.log("in searchFilter "+searchText)
        if(!arr){
            return [];
        }
        if(!searchText){
            return arr;
        }
        return arr.filter(p=>{return p.pname.includes(searchText)});
    }

}