import { Component,Input, Output,EventEmitter } from "@angular/core";


@Component(
    {
        selector:'ptab',
        templateUrl:'./persontab.component.html',
        styleUrls:['./persontab.component.css']

    }
)
export class PersonTabComponent{
    flagvar=true;
    searchData="";
    prodarr=[{pid:1,pname:"chiar",qty:23,price:345,mfgdate:"2021-09-01"},
    {pid:2,pname:"table",qty:23,price:3451,mfgdate:"2020-09-01"},
    {pid:3,pname:"shelf",qty:12,price:300,mfgdate:"2020-11-01"},
    {pid:3,pname:"rack",qty:10,price:3999,mfgdate:"2019-10-01"}];
    name:string;
  data:string="this is text from child";
  @Input("pdata") public msg:any={};
  @Output() public myevent=new EventEmitter();
  changedata(){
      this.myevent.emit(this.data);
  }
  toggleflag(){
      this.flagvar=!this.flagvar;
  }
}