import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
  ,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  flagvar=true;
  title = 'productsystem';
  name:string="Kishori";
  mydata={name:'',age:0};
  public message={};
  onclick(){
    this.mydata={name:this.name,age:20};
    this.flagvar=!this.flagvar;
    
  }
}
