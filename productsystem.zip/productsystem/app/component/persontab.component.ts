import { Component,Input, Output,EventEmitter } from "@angular/core";


@Component(
    {
        selector:'ptab',
        templateUrl:'./persontab.component.html',
        styleUrls:['./persontab.component.css']

    }
)
export class PersonTabComponent{
  data:string="this is text from child";
  @Input("pdata") public msg:any={};
  @Output() public myevent=new EventEmitter
  changedata(){
      this.myevent.emit(this.data);
  }
}