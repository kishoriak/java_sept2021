package com.demo.beans;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class User implements BeanNameAware,BeanFactoryAware,ApplicationContextAware,InitializingBean,DisposableBean{
	private int uid;
	private String uname;
	private String mobile;
	private Address addr1;
	List<String> hobbies;
	private float amt;
	public User() {
		super();
		hobbies=new ArrayList<>();
		System.out.println("in user default constructor");
	}
	public User(int uid, String uname, String mobile,Address addr,List<String> arr) {
		super();
		
		System.out.println("in user parametrised constructor");
		this.uid = uid;
		this.uname = uname;
		this.mobile = mobile;
		this.addr1=addr;
		this.hobbies=arr;
	}
	
	public float getAmt() {
		return amt;
	}
	public void setAmt(float amt) {
		this.amt = amt;
	}
	public Address getAddr1() {
		return addr1;
	}
	public void setAddr1(Address addr1) {
		this.addr1 = addr1;
	}
	public List<String> getHobbies() {
		return hobbies;
	}
	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}
	public Address getAddress() {
		return addr1;
	}
	public void setAddress(Address address) {
		System.out.println("in user setAddress method");
		this.addr1 = address;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		System.out.println("in user setuid method");
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		System.out.println("in user setuname method");
		this.uname = uname;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		System.out.println("in user setmobile method");
		this.mobile = mobile;
	}
	
	@Override
	public void setBeanName(String name) {
		System.out.println("in setBeanName "+name);
		
	}
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		System.out.println("in setBean factory "+beanFactory);
		
	}
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		System.out.println("in setAppliactionContext "+applicationContext);
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("in afterPropertiesSet ");
		
	}
	
	public void myinit() {
		this.amt=10000;
	}
	
	
	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", mobile=" + mobile + ", addr1=" + addr1 + ", hobbies="
				+ hobbies + ", amt=" + amt + "]";
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("in disposable bean destroy method");
		
	}
	
	public void mydestroy() {
		System.out.println("in custom destroy method");
	}
	
	
	

}
