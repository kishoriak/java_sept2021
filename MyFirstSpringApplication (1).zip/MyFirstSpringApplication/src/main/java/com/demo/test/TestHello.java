package com.demo.test;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.demo.beans.Address;
import com.demo.beans.HelloWorld;
import com.demo.beans.User;

public class TestHello {

	public static void main(String[] args) {
		//XmlBeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("springcfg.xml"));
		ApplicationContext ctx=new ClassPathXmlApplicationContext("springcfg.xml");
		HelloWorld hello=(HelloWorld)ctx.getBean("hw");
		System.out.println(hello.sayHello());
		User u1=(User)ctx.getBean("user1");
        System.out.println(u1);
       //User u21=(User)ctx.getBean("user2");
        //System.out.println(u21);
       // Address addr=(Address)ctx.getBean("add1");
        ((ClassPathXmlApplicationContext) ctx).close();
	}

}
