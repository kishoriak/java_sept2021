package com.demo.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class TestCollection {

	public static void main(String[] args) {
		Set<Integer> ob=new HashSet<>();
		ob.add(12);
		ob.add(13);
		ob.add(14);
		if(ob.add(13)) {
			System.out.println("added");
		}else {
			System.out.println("duplicate value");
		}
		System.out.println(ob);
		//System.out.println("capacity :"+((Vector)ob).capacity());
		System.out.println("Size:"+ob.size());
		for(int i=10;i<40;i++) {
			ob.add(i);
		}
		System.out.println(ob);
		//System.out.println("capacity :"+((Vector)ob).capacity());
		System.out.println("Size:"+ob.size());
		

	}

}
