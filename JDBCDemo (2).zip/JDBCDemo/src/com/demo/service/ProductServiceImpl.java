package com.demo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.demo.beans.Product;
import com.demo.dao.MyFactory;
import com.demo.dao.ProductDao;

public class ProductServiceImpl implements ProductService {
	private ProductDao productDao;
	
      public ProductServiceImpl() {
		super();
		this.productDao = MyFactory.getProductDao();
	}

	private static SimpleDateFormat sdf;
      static{
    	  sdf=new SimpleDateFormat("dd/MM/yy");
      }
      
    private Product acceptProduct() {
    	Scanner sc=new Scanner(System.in);
		System.out.println("enetr id");
		int id=sc.nextInt();
		System.out.println("enetr name");
		String nm=sc.next();
		System.out.println("enter qty");
		int qty= sc.nextInt();
		System.out.println("enter price");
		double pr= sc.nextDouble();
		System.out.println("enter type");
		String type= sc.next();
		System.out.println("enter date");
		String dt=sc.next();
		Date date=null;
		try {
			date=sdf.parse(dt);
			System.out.println("enter category id");
			int cid= sc.nextInt();
			Product p=new Product(id,nm,qty,pr,type,date,cid);
			return p;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
    }  
	@Override
	public void addProduct() {
		    Product p=acceptProduct();
			productDao.save(p);
	}

	@Override
	public void getAll() {
		List<Product> plist=productDao.findAll();
		plist.stream().forEach(System.out::println);
		
	}

	@Override
	public void closeConnection() {
		productDao.closeConnection();
		
	}

	@Override
	public Product getById(int id) {
		return productDao.findById(id);
		
	}

	@Override
	public List<Product> getByPrice(int lpr, int hpr) {
		return productDao.findByPrice(lpr,hpr);
	}

	@Override
	public boolean updateById(int id, int qty, double pr) {
		return productDao.updatedata(id,qty,pr);
	}

	@Override
	public boolean deleteById(int id) {
		return productDao.deleteById(id);
	}

	@Override
	public void addmany() {
		Scanner sc=new Scanner(System.in);
		List<Product> plist=new ArrayList<>();
		String ans="n";
		do {
		    Product p=acceptProduct();
		    plist.add(p);
			System.out.println("continue(y/n)");
			ans=sc.next();
		}while(ans.equals("y"));
		productDao.saveAll(plist);
		
	}

}
