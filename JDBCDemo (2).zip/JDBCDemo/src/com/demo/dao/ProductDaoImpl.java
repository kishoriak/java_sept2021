package com.demo.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Product;

public class ProductDaoImpl implements ProductDao {
	private static Connection conn;
	private static PreparedStatement inspr,prodall,pgetById,pgetByPrice,pupById,pdelById;
	
	static {
		try {
			conn=DBUtil.getMyConnection();
			inspr=conn.prepareStatement("insert into producthsbc values(?,?,?,?,?,?,?)");
			prodall=conn.prepareStatement("select * from producthsbc");
			pgetById=conn.prepareStatement("select * from producthsbc where pid=?");
			pgetByPrice=conn.prepareStatement("select * from producthsbc where price between ? and ? ");
			pupById=conn.prepareStatement("update producthsbc set qty=?,price=? where pid=?");
			pdelById=conn.prepareStatement("delete from  producthsbc where pid=?");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Override
	public void save(Product p) {
		try {
			inspr.setInt(1,p.getPid());
			inspr.setString(2,p.getPname());
			inspr.setInt(3,p.getQty());
			inspr.setDouble(4,p.getPrice());
			inspr.setString(5,p.getType());
			java.sql.Date sdat=new java.sql.Date(p.getMfg().getTime());
			inspr.setDate(6, sdat);
			inspr.setInt(7,p.getCid());
			int num=inspr.executeUpdate();
			if (num>0) {
				conn.commit();
			}
			
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			//e.printStackTrace();
		}
		
		
	}


	@Override
	public List<Product> findAll() {
		try {
			List<Product> plist=new ArrayList<>();
			ResultSet rs=prodall.executeQuery();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getString(5),rs.getDate(6),rs.getInt(7)));
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public void closeConnection() {
		DBUtil.closeMyConnection();
		
	}


	@Override
	public Product findById(int id) {
		try {
			pgetById.setInt(1, id);
			ResultSet rs=pgetById.executeQuery();
			if(rs.next()) {
				return new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getString(5),rs.getDate(6),rs.getInt(7));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public List<Product> findByPrice(int lpr, int hpr) {
		List<Product> plist=new ArrayList<>();
		try {
			pgetByPrice.setDouble(1, lpr);
			pgetByPrice.setDouble(2, hpr);
			ResultSet rs=pgetByPrice.executeQuery();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getString(5),rs.getDate(6),rs.getInt(7)));
			}
			if(plist.size()>0)
			   return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public boolean updatedata(int id, int qty, double pr) {
		try {
			pupById.setInt(1, qty);
			pupById.setDouble(2,pr);
			pupById.setInt(3, id);
			int num=pupById.executeUpdate();
			if(num>0) {
				conn.commit();
				return true;
			}
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		return false;
	}


	@Override
	public boolean deleteById(int id) throws ProductNotFoundException{
		try {
			pdelById.setInt(1, id);
			int num=pdelById.executeUpdate();
			if(num>0) {
				conn.commit();
				return true;
			}
			
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				throw new ProductNotFoundException("not found");
				//e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return false;
	}


	@Override
	public void saveAll(List<Product> plist) {
		int cnt=0;
		Savepoint[] sarr=new Savepoint[plist.size()];
		for(Product p:plist) {
			try {
				inspr.setInt(1,p.getPid());
				inspr.setString(2,p.getPname());
				inspr.setInt(3,p.getQty());
				inspr.setDouble(4,p.getPrice());
				inspr.setString(5,p.getType());
				java.sql.Date sdat=new java.sql.Date(p.getMfg().getTime());
				inspr.setDate(6, sdat);
				inspr.setInt(7,p.getCid());
				inspr.addBatch();
				sarr[cnt]=conn.setSavepoint("s"+cnt);
				cnt++;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		try {
			int[] numarr=new int[plist.size()];
		    numarr=inspr.executeBatch();
		    int i=0;
		    while(numarr[i]>0) {
		    	i++;
		    }
		    if(i==plist.size())
		    	conn.commit();
		    else
		        conn.rollback(sarr[i-1]);
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
