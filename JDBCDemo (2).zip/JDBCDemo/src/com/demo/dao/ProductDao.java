package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao {

	void save(Product p);

	List<Product> findAll();

	void closeConnection();

	Product findById(int id);

	List<Product> findByPrice(int lpr, int hpr);

	boolean updatedata(int id, int qty, double pr);

	boolean deleteById(int id);

	void SaveAll(List<Product> plist);

	void saveAll(List<Product> plist);

}
