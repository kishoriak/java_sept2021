package com.demo.beans;

public class Category {
	private int catid;
	private String cname;
	public Category() {
		super();
	}
	public Category(int catid, String cname) {
		super();
		this.catid = catid;
		this.cname = cname;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	

}
