package com.demo.sevlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.beans.Category;
import com.demo.beans.Product;

/**
 * Servlet implementation class ShowCartDetails
 */
@WebServlet("/showcart")
public class ShowCartDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession sess=request.getSession();
		List<Product> cart=(List<Product>) sess.getAttribute("cart");
	
		 out.println("<table border='2'>");
		  out.println("<tr><th>product id</th><th>Product name</th><th>Quantity</th><th>price</th></tr>");
		  for(Product p:cart) {
			  out.println("<tr>");
			  out.println("<td>"+p.getPid()+"</td><td>"+p.getName()+"</td><td>"+p.getQty()+"</td><td>"+p.getPrice()+"</td>");
			  out.println("</tr>");
			  
		  }
		  out.println("</table>");
		out.println("<a href='category'>Add more product</a><br>");
		out.println("<a href='payBill'>Pay bill</a>");
		
	}

}
