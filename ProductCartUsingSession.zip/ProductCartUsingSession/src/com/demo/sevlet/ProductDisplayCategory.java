package com.demo.sevlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.beans.Category;
import com.demo.beans.Product;
import com.demo.beans.User;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductDisplayCategory
 */
@WebServlet("/displayprod")
public class ProductDisplayCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession sess=request.getSession();
		User u=(User) sess.getAttribute("user");
		if(u!=null){
			int cid=Integer.parseInt(request.getParameter("cid"));
			ProductService pservice=new ProductServiceImpl();
			List<Product> plist=pservice.getProductByCategory(cid);
			//out.println("Welcome "+u.getUname());
			out.println("<form action='addcart'>");
			   
			for(Product p:plist) {
				out.println("<input type='checkbox' name='prod' id='p1' value='"+p.getPid()+"'><label for='p1'>"+p.getName()+"----"+p.getPrice()+"</label><br>");
				
			}
			out.println("<button type='submit' name='btn'>Add to cart</button>");
			out.println("</form>");
		}
		else {
			out.println("<h4>pls re enter credentials</h4>");
			RequestDispatcher rd=request.getRequestDispatcher("LoginForm.html");
			rd.include(request,response);
		}
		
	}

}
