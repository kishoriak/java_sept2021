package com.demo.sevlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Category;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class CategoryServlet
 */
@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		ProductService pservice=new ProductServiceImpl();
		List<Category> clist=pservice.getAllCategory();
		out.println("<form action='displayprod'>");
		out.println("<select name='cid'>");
		for(Category c:clist) {
			out.println("<option value='"+c.getCatid()+"'>"+c.getCname()+"</option>");
			
		}
		out.println("</select>");
		out.println("<button type='submit' name='btn'>Show product</button>");
		out.println("</form>");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

}
