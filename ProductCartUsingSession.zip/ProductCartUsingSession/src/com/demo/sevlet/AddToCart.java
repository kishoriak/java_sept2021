package com.demo.sevlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.beans.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class AddToCart
 */
@WebServlet("/addcart")
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String[] pidarr=request.getParameterValues("prod");  //[12,34,2]
		ProductService pservice=new ProductServiceImpl();
		List<Product> plist=pservice.getAllSelected(pidarr);
		HttpSession sess=request.getSession();
		List<Product> cart=(List<Product>) sess.getAttribute("cart");
		//generate cart only if we are comming to this servlet 1 st time
		if(cart==null) {
			cart=new ArrayList<>();
		}
		//add all seletected products into cart
		for(Product p:plist) {
			cart.add(p);
		}
		//overwriting old cart with new cart
		sess.setAttribute("cart",cart);
		RequestDispatcher rd=request.getRequestDispatcher("showcart");
		rd.forward(request, response);
		
	}

}
