package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.demo.beans.Category;
import com.demo.beans.Product;

public class ProductDaoImpl implements ProductDao{
	private static Connection con;
	private static PreparedStatement pgetAll,pins,pdelById,pgetById,pupdateById,pgetAllcat,pgetProdByCat;
	static {
		
		try {
			con=DBUtil.getMyConnection();
			pgetAll=con.prepareStatement("select * from product");
			pins=con.prepareStatement("insert into product values(?,?,?,?)");
			pdelById=con.prepareStatement("delete from product where pid=?");
			pgetById=con.prepareStatement("select * from product where pid=?");
			pupdateById=con.prepareStatement("update product set pname=?,qty=?,price=? where pid=?");
			pgetProdByCat=con.prepareStatement("select * from product where cid=?");
			pgetAllcat=con.prepareStatement("select * from category");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	@Override
	public List<Product> findAll() {
		List<Product> plist=new ArrayList<>();
		try {
			ResultSet rs=pgetAll.executeQuery();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4)));
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public void save(Product p) {
		try {
			pins.setInt(1, p.getPid());
			pins.setString(2, p.getName());
			pins.setInt(3, p.getQty());
			pins.setDouble(4, p.getPrice());
			int n=pins.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}


	@Override
	public void deleteById(int pid) {
		try {
			pdelById.setInt(1, pid);
			pdelById.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	@Override
	public Product findById(int pid) {
		try {
			pgetById.setInt(1, pid);
			ResultSet rs=pgetById.executeQuery();
			if(rs.next()) {
				return new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}


	@Override
	public Object updateById(Product p) {
		try {
			pupdateById.setString(1, p.getName());
			pupdateById.setInt(2,p.getQty());
			pupdateById.setDouble(3, p.getPrice());
			pupdateById.setInt(4,p.getPid());
			pupdateById.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public List<Category> findAllCategory() {
		try {
			List<Category> clist=new ArrayList<>();
			ResultSet rs=pgetAllcat.executeQuery();
			while(rs.next()) {
				clist.add(new Category(rs.getInt(1),rs.getString(2)));
				
			}
			return clist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public List<Product> findProductByCategory(int cid) {
		try {
			pgetProdByCat.setInt(1, cid);
			List<Product> plist=new ArrayList<>();
			ResultSet rs=pgetProdByCat.executeQuery();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4)));
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public List<Product> findAllselecetd(String[] pidarr) {
		//[12,34,2]
		     
		try {
			String sql=String.format("select * from product where pid in (%s)",Stream.of(pidarr).map(v->"?").collect(Collectors.joining(", ")));
			System.out.println(sql);
			PreparedStatement pst=con.prepareStatement(sql);
			int index=1;
			for(String s:pidarr) {
				pst.setInt(index, Integer.parseInt(s));
				index++;
			}
			List<Product> plist=new ArrayList<>();
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4)));
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

}
