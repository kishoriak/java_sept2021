package com.demo.dao;

import java.util.List;

import com.demo.beans.Category;
import com.demo.beans.Product;

public interface ProductDao {

	List<Product> findAll();

	void save(Product p);

	void deleteById(int pid);

	Product findById(int pid);

	Object updateById(Product p);

	List<Category> findAllCategory();

	List<Product> findProductByCategory(int cid);

	List<Product> findAllselecetd(String[] pidarr);

}
