package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.beans.User;

public class UserDaoImpl implements UserDao{
	private static Connection con;
	private static PreparedStatement pgetUser;
	static {
		con=DBUtil.getMyConnection();
		try {
			pgetUser=con.prepareStatement("select * from user where uname=? and password=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public User getUser(String uname, String pass) {
		try {
			pgetUser.setString(1, uname);
			pgetUser.setString(2, pass);
			ResultSet rs=pgetUser.executeQuery();
			if(rs.next()) {
				return new User(rs.getString(1),rs.getString(2),rs.getString(3));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

}
