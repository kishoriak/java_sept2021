package com.demo.service;

import com.demo.beans.User;
import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

public class UserServiceImpl implements UserService{
	private UserDao userDao;

	public UserServiceImpl() {
		userDao=new UserDaoImpl();
	}

	@Override
	public User validateUser(String uname,String pass) {
		User u=userDao.getUser(uname,pass);
		if(u!=null) {
		System.out.println("Role :" +u.getRole());
		if((u.getUname().equals(uname)) && (u.getPassword().equals(pass))){
			return u;
		}
		}
		return null;
	}
	

}
