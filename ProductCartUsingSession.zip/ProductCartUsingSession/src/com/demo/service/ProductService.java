package com.demo.service;

import java.util.List;


import com.demo.beans.Product;
import com.demo.beans.Category;

public interface ProductService {

	List<Product> getAllProducts();

	void addProduct(Product p);

	void deleteById(int pid);

	Product getById(int pid);

	void updateProduct(Product p);

	List<Category> getAllCategory();

	List<Product> getProductByCategory(int cid);

	List<Product> getAllSelected(String[] pidarr);

}
