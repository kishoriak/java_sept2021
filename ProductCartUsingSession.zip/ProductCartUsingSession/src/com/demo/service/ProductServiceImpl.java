package com.demo.service;

import java.util.List;

import com.demo.beans.Category;
import com.demo.beans.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{
	private ProductDao productDao;
	

	public ProductServiceImpl() {
		productDao=new ProductDaoImpl();
	}


	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}


	@Override
	public void addProduct(Product p) {
		productDao.save(p);
		
	}


	@Override
	public void deleteById(int pid) {
		productDao.deleteById(pid);
	}


	@Override
	public Product getById(int pid) {
		return productDao.findById(pid);
	}


	@Override
	public void updateProduct(Product p) {
		productDao.updateById(p);
		
	}


	@Override
	public List<Category> getAllCategory() {
		return productDao.findAllCategory();
	}


	@Override
	public List<Product> getProductByCategory(int cid) {
		return productDao.findProductByCategory(cid);
	}


	@Override
	public List<Product> getAllSelected(String[] pidarr) {
		return productDao.findAllselecetd(pidarr);
	}

}
