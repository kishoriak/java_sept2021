package com.demo.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.beans.Product;
import com.demo.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productService;
	
	@GetMapping("/viewProducts")
	public ModelAndView displayProducts() {
		List<Product> plist=productService.getAllProduct();
		return new ModelAndView("displayproduct","plist",plist);
		
	}
	
	@GetMapping("/addproduct")
	public String addProduct() {
		return "insertproduct";
		
	}
	
	@PostMapping("/saveData")
	public ModelAndView addProductDetails(@RequestParam int pid,@RequestParam String pname,@RequestParam int qty,@RequestParam double price,@RequestParam String dt) {
		Product p=new Product(pid,pname,qty,price,LocalDate.parse(dt,DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		productService.addProduct(p);
		return new ModelAndView("redirect:/product/viewProducts");
	}
	
	
	

}
