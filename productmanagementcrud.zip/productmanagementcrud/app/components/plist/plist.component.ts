import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'plist',
  templateUrl: './plist.component.html',
  styleUrls: ['./plist.component.css']
})
export class PlistComponent implements OnInit {

  constructor(private pservice:ProductService) { }

  ngOnInit(): void {
    this.pservice.getProducts().subscribe(response=>{this.prodarr=response});
  }

  prodarr:Product[];

}
