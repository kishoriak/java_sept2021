import { Component, OnInit, Output ,EventEmitter, Input, SimpleChanges} from '@angular/core';

import { Product } from 'src/app/Product';
import { ProductService } from 'src/app/product.service';


@Component({
  selector: 'pform',
  templateUrl: './pform.component.html',
  styleUrls: ['./pform.component.css']
})
export class PformComponent implements OnInit {

  constructor(private pservice:ProductService) { }

  ngOnInit(): void {
  }
  
  ngOnChanges(changes: SimpleChanges) {
    console.log("in ng on changes of pform component")
    console.log(changes);
    console.log(changes['prod'].currentValue);
    if(changes['prod'].currentValue!==changes['prod'].previousValue){
      if(changes['adflag'].currentValue==='e'){
          this.pid=this.prod.pid;
          this.pname=this.prod.pname;
          this.qty=this.prod.qty;
          this.price=this.prod.price;
          this.mfgdate=this.prod.mfgdate;
      }
      else{
        this.pid=NaN;
        this.pname="";
        this.qty=NaN;
        this.price=NaN;
        this.mfgdate=new Date(0);
      }
    }
}

  pid:number=NaN;
  pname="";
  qty=0;
  price=0;
  mfgdate:Date;
  @Output() public myevent=new EventEmitter();
  @Input("addupdateflag") public adflag:string="";
  @Input("prod") public prod:Product;
  addProduct(){
    let p=new Product(this.pid,this.pname,this.qty,this.price,this.mfgdate)
    console.log(p);
    this.pservice.addProduct(p)
    .subscribe(response=>{console.log(response);
    this.pid=0;
    this.pname="";
    this.qty=0;
    this.price=0.0;

    this.mfgdate=new Date(0);
    this.myevent.emit(false);
   });
     
  }
  updateProduct(){
    console.log("in update product");
    let p=new Product(this.pid,this.pname,this.qty,this.price,this.mfgdate)
    console.log(p);
    this.pservice.updateProduct(p)
    .subscribe(response=>{console.log(response);
    this.pid=0;
    this.pname="";
    this.qty=0;
    this.price=0.0;

    this.mfgdate=new Date(0);
    this.myevent.emit(false);
  }

}
