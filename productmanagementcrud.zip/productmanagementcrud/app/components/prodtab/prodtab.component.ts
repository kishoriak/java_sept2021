import { Component,Input, Output,EventEmitter ,OnChanges,SimpleChange} from "@angular/core";
import { watch } from "fs";
import { ProductService } from "src/app/product.service";
import {Product} from '../../Product';

@Component(
    {
        selector:'ptab',
        templateUrl:'./prodtab.component.html',
        styleUrls:['./prodtab.component.css']

    }
)
export class ProdtabComponent{
  prodarr:Product[];
 
  flagvar=false;
  prod:Product;
  auflag:string="";
   constructor(private pservice:ProductService){

   }
  ngOnInit(){
     this.pservice.getProducts().subscribe(response=>{this.prodarr=response;});
      console.log(this.prodarr);
  }

  ngOnChanges ( changes:SimpleChange){
    console.log("in ngOnchanges of ptab")
    console.log(changes);

  }
  deleteProduct(pid:number){
    this.pservice.deleteProduct(pid).subscribe(response=>console.log(response));

  }
  editProduct(p:Product,ch:string){
    this.auflag=ch;
    this.prod=new Product(p.pid,p.pname,p.qty,p.price,p.mfgdate);
    this.flagvar=true;
     console.log("in edit product")
  }
  onclick(ch:string){
    this.prod=new Product(0,"",0,0.0,new Date(0));
    this.auflag=ch;
    this.flagvar=true;
  }
  
}
