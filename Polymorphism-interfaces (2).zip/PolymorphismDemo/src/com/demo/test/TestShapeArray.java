package com.demo.test;
import java.util.Scanner;

import com.demo.beans.Shape;
import com.demo.service.ShapeServiceImpl;

public class TestShapeArray {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int choice;
	ShapeServiceImpl service=new ShapeServiceImpl();
	do {
	System.out.println("1.add new shape\n2.calculate area\n3.display area of all\n");
	System.out.println("4.calculate Perimeter\n5.exit");
	choice=sc.nextInt();
	Shape s=null;
	switch(choice) {
	//triangle class
	case 1:
		System.out.println("1.Triangle\n2.Circle\n3.Rectangle");
		System.out.println("choice");
		int ch1=sc.nextInt();
		service.addShape(ch1);
		break;
		//circle class
	case 2:
		System.out.println("accept position");
		int pos=sc.nextInt();
		float area=service.getArea(pos);
		if(area!=-1)
			System.out.println("Area : "+area);
		else {
			System.out.println("not found");
		}
		
		break;
	case 3:
		service.showAreaForAll();
		break;
	case 4:
		System.out.println("accept position");
		pos=sc.nextInt();
		float peri=service.getPerimeter(pos);
		if(peri!=-1)
			System.out.println("perimeter : "+peri);
		else {
			System.out.println("not found");
		}
		break;
	case 5:
		System.exit(0);
		break;
	}
	
	}while(choice!=4);


}
}
