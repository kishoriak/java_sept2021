package com.demo.dao;

import com.demo.beans.Shape;

public interface ShapeDao {
	public void addData(Shape s);
	public float getArea(int pos);
	public float getPerimeter(int pos);
	public Shape[] getAllShapes();
}
