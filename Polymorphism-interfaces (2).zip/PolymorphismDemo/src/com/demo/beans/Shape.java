package com.demo.beans;

abstract public class Shape {
	private String color;
	private int dimenssion;
	public Shape() {
		super();
	}
	public Shape(String color, int dimenssion) {
		super();
		this.color = color;
		this.dimenssion = dimenssion;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getDimenssion() {
		return dimenssion;
	}
	public void setDimenssion(int dimenssion) {
		this.dimenssion = dimenssion;
	}
	abstract public float calculateArea();
	abstract public float calculatePerimeter();
	@Override
	public String toString() {
		return "Shape [color=" + color + ", dimenssion=" + dimenssion + "]";
	}
	
	
	

}
