package com.demo.service;

public interface ShapeService {
	void addShape(int ch1);
	public float getArea(int pos);
	public float getPerimeter(int pos);
	public void showAreaForAll(); 
}
