package com.demo.service;
import java.util.Scanner;
import java.util.stream.Stream;

import com.demo.beans.Circle;
import com.demo.beans.Shape;
import com.demo.beans.Triangle;
import com.demo.dao.ShapeDaoImpl;

public class ShapeServiceImpl implements ShapeService {
	private int i;
	private ShapeDaoImpl sdao;
	

	public ShapeServiceImpl() {
		
		sdao=new ShapeDaoImpl();
	}


	public void addShape(int ch1) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Color");
		String cl=sc.next();
		System.out.println("enetr dimenssions");
		int dm=sc.nextInt();
		switch(ch1) {
		case 1:
			System.out.println("enetr base");
			float b=sc.nextFloat();
			System.out.println("enetr height");
			float h=sc.nextFloat();
			System.out.println("enetr side1");
			float s1=sc.nextFloat();
			System.out.println("enetr side2");
			float s2=sc.nextFloat();
			sdao.addData(new Triangle(cl,dm,b,h,s1,s2));
			break;
		case 2:
			System.out.println("enetr radius");
			float r=sc.nextFloat();
			sdao.addData(new Circle(cl,dm,r));
			break;
		case 3:
			break;
		}
	}


	public float getArea(int pos) {
		return sdao.getArea(pos);
	}


	public float getPerimeter(int pos) {
		return sdao.getPerimeter(pos);
	}


	public void showAreaForAll() {
		Shape[] arr=sdao.getAllShapes();
		for(Shape s:arr) {
			System.out.println("Area : "+ s.calculateArea());
		}
		
		//Stream.of(arr).forEach(ob->{System.out.println(ob.calculateArea());});
		
	}

}
