package com.demo.service;

public interface InterfaceTwo {
	void m1();
	int i=10;
	/* default void m2() {
		System.out.println("in default method m22222");
	}*/
	void m2();
	
	void m24();
	
}
