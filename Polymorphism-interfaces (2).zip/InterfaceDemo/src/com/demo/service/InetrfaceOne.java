package com.demo.service;

public interface InetrfaceOne {
	void m1();
	int i=10;
	default void m2() {
		System.out.println("in default method m2");
	}
	

}
