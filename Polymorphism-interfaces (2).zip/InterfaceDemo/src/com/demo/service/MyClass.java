package com.demo.service;

abstract public class MyClass implements InetrfaceOne,InterfaceTwo{

	@Override
	public void m1() {
		System.out.println("In m1");
		
	}

	
	public int m3() {
		System.out.println("in m3");
		return 0;
	}


	


	@Override
	public void m24() {
		// TODO Auto-generated method stub
		
	}


	@Override
	abstract public void m2() ;


	


	


	


	


	

}
