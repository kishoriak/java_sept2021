package com.demo.test;

import com.demo.service.InetrfaceOne;
import com.demo.service.MyClass;

public class TestInterfaces {

	public static void main(String[] args) {
		MyClass ob=new MyClass();
		ob.m1();
		ob.m2();
        ob.m3();
        InetrfaceOne ob1=new MyClass();
        ob1.m1();
        ((MyClass)ob1).m3();
       
        System.out.println(InetrfaceOne.i);
	}

}
