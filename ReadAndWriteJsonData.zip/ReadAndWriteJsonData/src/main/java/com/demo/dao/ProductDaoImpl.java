package com.demo.dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ProductDaoImpl implements ProductDao{

	public JSONArray getJsonFileData(String path) {
		JSONParser jsonParser=new JSONParser();
		try {
			FileReader fr=new FileReader(path);
			Object obj=jsonParser.parse(fr);
			JSONObject jobj=(JSONObject)obj;
			return (JSONArray) jobj.get("products");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
