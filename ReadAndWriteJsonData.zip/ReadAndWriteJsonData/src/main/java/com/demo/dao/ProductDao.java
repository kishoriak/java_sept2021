package com.demo.dao;

import org.json.simple.JSONArray;

public interface ProductDao {
   JSONArray getJsonFileData(String path);
}
