package com.demo.service;

import org.json.simple.JSONArray;

import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {
	ProductDao pdao;

	public ProductServiceImpl() {
		super();
		pdao=new ProductDaoImpl();
	}

	public JSONArray getFileData(String path) {
		System.out.println("name :"+path);
		return pdao.getJsonFileData(path);
	}

}
