package com.demo.service;

import org.json.simple.JSONArray;

public interface ProductService {

	JSONArray getFileData(String path);

}
