package com.demo.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
//@Scope("prototype")
public class MyClass {
	@Value("10")
	private int x;
	@Value("11")
	private int y;

	public MyClass() {
		super();
		System.out.println("in default constructor");
	}

	public MyClass(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	public void mymethod() {
		
		System.out.println("in Myclass mymethod");
	}

	public int getX() {
		
		return x;
	}

	public void setX(int x) {
		this.x = x;
		System.out.println("in setX");
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
		System.out.println("in setY");
	}

	@Override
	public String toString() {
		return "MyClass [x=" + x + ", y=" + y + "]";
	}
	

}
