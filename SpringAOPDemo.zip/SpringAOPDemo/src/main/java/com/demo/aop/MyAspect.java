package com.demo.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAspect {
	
	@Pointcut("execution(* com.demo.beans.*.*(..)),execution(* com.demo.beans.*.w*(double))")
	public void method1() {}
	
	/*@Pointcut("execution(* com.demo.beans.*.w*(double))")
	public void method2() {}*/
	
	@Before("method1()")
	public void beforeAdvice1() {
		System.out.println("in before advice1 security");
	}

}
