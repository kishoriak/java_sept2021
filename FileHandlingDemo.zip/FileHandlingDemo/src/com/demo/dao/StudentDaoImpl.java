package com.demo.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

import com.demo.beans.Student;

public class StudentDaoImpl implements StudentDao{
	private static Student[] studarr;
	private static int cnt;
	static {
		studarr=new Student[10];
		cnt=0;
		/*studarr[0]=new Student(12,"Rajan",98,99,99);
		studarr[1]=new Student(13,"Vedant",98,99,99);
		studarr[2]=new Student(14,"Prathmesh",98,99,99);
		cnt=3;*/
	}
	@Override
	public void saveStudent(Student student) {
		studarr[cnt]=student;
		cnt++;
	}
	@Override
	public Student[] getAll() {
		return Arrays.copyOfRange(studarr,0,cnt);
	}
	@Override
	public void writeToFile() {
		try (ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("stddata.txt"));){
			for(Student s:studarr) {
				if(s!=null) 
					oos.writeObject(s);
				else
					break;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void readFromFile() {
		File f=new File("stddata.txt");
		if(f.exists()) {
			try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));) {
				
				cnt=0;
				while(true) {
					
					Student s=(Student) ois.readObject();
					studarr[cnt]=s;
					cnt++;
					
				}						
			} catch(EOFException e) {
				System.out.println("reached to end of file ......"+cnt);
			}catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			System.out.println("no file exists");
		}
		
	}

}
