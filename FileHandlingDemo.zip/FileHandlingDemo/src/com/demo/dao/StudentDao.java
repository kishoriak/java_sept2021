package com.demo.dao;

import com.demo.beans.Student;

public interface StudentDao {

	void saveStudent(Student student);

	Student[] getAll();

	void writeToFile();

	void readFromFile();

}
