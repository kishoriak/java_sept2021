package com.demo.beans;

import java.io.Serializable;

public class Student implements Serializable{
	private int sid;
	private String sname;
	private float m1,m2,m3;
	
	//default constructor
	public Student() {
		sid=0;
		sname=null;
		m1=0;
		m2=0;
		m3=0;
	}
	
	//parametrized constructor
	public Student(int id,String nm,int m1,int m2,int m3) {
		sid=id;
		sname=nm;
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
	}
	
	public void setSid(int id) {
		this.sid=id;
	}
	
	public int getSid() {
		return sid;
	}
	public void setSname(String nm) {
		this.sname=nm;
	}
	
	public String getSname() {
		return sname;
	}
	public void setM1(float m1) {
		this.m1=m1;
	}
	
	public float getM1() {
		return m1;
	}
	public void setM2(float m2) {
		this.m2=m2;
	}
	
	public float getM2() {
		return m2;
	}
	public void setM3(float m3) {
		this.m3=m3;
	}
	
	public float getM3() {
		return m3;
	}
	
	public String displayData() {
		return "Id: "+ sid +" Name : "+sname+"Marks 1 : "+m1+"Marks2 :"+m2+"Marks 3 : "+m3; 
		
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", m1=" + m1 + ", m2=" + m2 + ", m3=" + m3 + "]";
	}
	
}
