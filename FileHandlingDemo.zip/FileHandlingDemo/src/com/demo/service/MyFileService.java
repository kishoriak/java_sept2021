package com.demo.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MyFileService {

	public static void copyData(String inpf, String outpf) throws FileNotFoundException  {
		BufferedOutputStream bos=null;
		File f=new File(outpf);
		if(f.exists()) {
			bos=new BufferedOutputStream(new FileOutputStream(outpf,true));
		}else {
			bos=new BufferedOutputStream(new FileOutputStream(outpf));
		}
		try(BufferedInputStream bis=new BufferedInputStream(new FileInputStream(inpf));
			BufferedOutputStream boo=bos;	) {
			
			   int data=bis.read();
			   while(data!=-1) {
				   boo.write(data);
				   data=bis.read();
			   }
			
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e1) {
			
		}
		
	}

}
