package com.demo.service;

public interface StudentService {

	void addStudent();

	void displayAll();

	void writedata();

	void readData();

}
