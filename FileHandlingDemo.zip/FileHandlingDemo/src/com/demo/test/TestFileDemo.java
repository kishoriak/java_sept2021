package com.demo.test;

import java.io.FileNotFoundException;

import com.demo.service.MyFileService;

public class TestFileDemo {

	public static void main(String[] args) {
		try {
			MyFileService.copyData("testdata.txt","testcopy.txt");
		} catch (FileNotFoundException e) {
			System.out.println("file name is wrong");
		}

	}

}
