package com.demo.test;

import java.util.Scanner;

import com.demo.service.StudentService;
import com.demo.service.StudentServiceImpl;

public class TestSerialization {

	public static void main(String[] args) {
		StudentService ss=new StudentServiceImpl();
		Scanner sc=new Scanner(System.in);
		int choice=0;
		ss.readData();
		do {
		
		System.out.println("1. add student\n2.search student\n3. display all\n4.exit\n");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			ss.addStudent();
			break;
		case 2:
			break;
		case 3:
			ss.displayAll();
			break;
		case 4:
			ss.writedata();
			System.out.println("Thank you visiting....");
			break;
		}
		}while(choice!=4);
	}

}
